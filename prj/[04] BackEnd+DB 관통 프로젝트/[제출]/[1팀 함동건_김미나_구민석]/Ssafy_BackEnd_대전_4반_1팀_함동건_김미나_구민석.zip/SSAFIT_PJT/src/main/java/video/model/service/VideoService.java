package video.model.service;

import java.util.List;

import video.model.dto.Video;

public interface VideoService {

	Video selectVideoById(String video_id) throws Exception;

	List<Video> selectAllVideos() throws Exception;

	void updateViewCnt(String video_id) throws Exception;

}
