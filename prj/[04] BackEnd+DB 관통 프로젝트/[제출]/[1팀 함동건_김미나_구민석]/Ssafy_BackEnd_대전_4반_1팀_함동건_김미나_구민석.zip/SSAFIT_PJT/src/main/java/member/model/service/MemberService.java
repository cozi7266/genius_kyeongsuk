package member.model.service;

import member.model.dto.Member;

public interface MemberService {

	Member selectMember(Member param) throws Exception;

	void insertMember(Member member) throws Exception;

}
