package member.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import db.utill.DBUtil;
import member.model.dto.Member;

public class MemberDaoImpl implements MemberDao {
	// 회원 정보 관리 데이터베이스(메모리)
	private Map<String, Member> memberMap = new HashMap<>();
	private static MemberDao instance = new MemberDaoImpl();

	private MemberDaoImpl() {
	}

	public static MemberDao getInstance() {
		return instance;
	}

	// DB유틸 객체 생성

	private DBUtil dbUtil = DBUtil.getInstance();

	@Override
	public void insertMember(Member member) throws SQLException {
		String sql = "INSERT INTO member (user_id, user_password, user_name) VALUES (?, ?, ?)";
		try (
				// 데이터베이스 연결하기
				Connection con = dbUtil.getConnection(); // 연결-워크벤치 들어온 것과 같음

				// SQL문을 실행할 객체를 얻어온다. (연결 객체로부터)
				PreparedStatement pstmt = con.prepareStatement(sql);

		) {

			pstmt.setString(1, member.getUserId());
			pstmt.setString(2, member.getUserPassword());
			pstmt.setString(3, member.getUserName());

			pstmt.executeUpdate();

		}

	}

	@Override
	public Member selectMember(Member member) throws SQLException {
		// 로그인 창에서 입력한 아이디, 패스워드를 받아옴
		// DB에 저장된 정보 중 일치하는 정보 있으면 가져옴
		String sql = "SELECT user_id, user_password, user_name FROM member WHERE user_id = ?";

		try (
				// 데이터베이스 연결하기
				Connection con = dbUtil.getConnection();

				// 실행할 SQL 문 작성
				// 아이디와 일치하는 비밀번호 가져오기
				// 가져와서 일치하는지 확인하기
				// SQL문을 실행할 객체를 얻어온다.
				PreparedStatement pstmt = con.prepareStatement(sql);

		)

		{
			
			// SQL문을 실행 전에 ?에 값을 설정하자.
			pstmt.setString(1, member.getUserId());
			
			try (
					// SQL문 실행하기 : select(executeQuery), select절 이외(executeUpdate)
					ResultSet rs = pstmt.executeQuery();
					
					) {
				
				
				if (rs.next()) { // 결과 값이 있으면
					String id = rs.getString("user_id");
					String password = rs.getString("user_password");
					String name = rs.getString("user_name");
					Member m = new Member();
					m.setUserId(id);
					m.setUserName(name);
					m.setUserPassword(password);
					if (member.getUserPassword().equals(password)) {
						return m;
					}
					
				}
				return null;
			}


		}
	}
}
