package review.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import db.utill.DBUtil;
import review.model.dto.Review;

public class ReviewDaoImpl implements ReviewDao {
	// 싱글톤 패턴
	private ReviewDaoImpl() {
	}

	private static ReviewDao instance = new ReviewDaoImpl();

	public static ReviewDao getInstance() {
		return instance;
	}

	// DB유틸 객체 생성
	private DBUtil dbUtil = DBUtil.getInstance();

	// 리뷰 등록
	@Override
	public void insertReview(Review review) throws SQLException {
		// 데이터베이스 연결하기
		String sql = "INSERT INTO video_review (review_title, review_writer, review_content, review_id) VALUES (?, ?, ?, ?)";
		try (Connection con = dbUtil.getConnection(); // 연결-워크벤치 들어온 것과 같음
				PreparedStatement pstmt = con.prepareStatement(sql);)

		{
			pstmt.setString(1, review.getReviewTitle());
			pstmt.setString(2, review.getReviewWriter());
			pstmt.setString(3, review.getReviewContent());
			pstmt.setString(4, review.getReviewId());
			pstmt.executeUpdate();
		}
		// SQL문을 실행할 객체를 얻어온다. (연결 객체로부터)
	}

	// 리뷰 전체 조회
	@Override
	public List<Review> selectAllReviews(String video_id) throws SQLException {
		List<Review> reviews = new ArrayList<>();
		String sql = "SELECT review_no, review_title, review_writer, review_content, review_id from video_review where review_id = ? ORDER BY reg_date DESC";

		try (

				// 데이터베이스 연결하기
				Connection con = dbUtil.getConnection();
				// 실행할 SQL 문 작성
				// 영상 아이디에 해당하는 리뷰 목록 전체 반환
				// SQL문을 실행할 객체를 얻어온다.
				PreparedStatement pstmt = con.prepareStatement(sql);)

		{
			pstmt.setString(1, video_id);

			try (
					// SQL문 실행하기 : select(executeQuery), select절 이외(executeUpdate)
					ResultSet rs = pstmt.executeQuery();

			) {
				while (rs.next()) { // 결과 값이 있으면
					int review_no = rs.getInt("review_no");
					String review_title = rs.getString("review_title");
					String review_writer = rs.getString("review_writer"); // 연동 해조야됨
					String review_content = rs.getString("review_content");
					String review_id = rs.getString("review_id");
//			String reg_date = rs.getString("reg_date");
					Review r = new Review();
					r.setReviewNo(review_no);
					r.setReviewTitle(review_title);
					r.setReviewWriter(review_writer);
					r.setReviewContent(review_content);
					r.setReviewId(review_id);
					reviews.add(r);
				}

				return reviews;

			}
		}
	}

	// 리뷰 삭제
	@Override
	public void deleteReview(int no) throws SQLException {
		// 해당 번호의 리뷰를 삭제해야함
		// 데이터베이스 연결하기

		String sql = "DELETE FROM video_review where review_no = ?;";
		try (Connection con = dbUtil.getConnection(); // 연결-워크벤치 들어온 것과 같음
				PreparedStatement pstmt = con.prepareStatement(sql);

		)

		{
			// SQL문을 실행할 객체를 얻어온다. (연결 객체로부터)

			// SQL문을 실행 전에 ?에 값을 설정하자.
			// 삭제할 번호 넘겨줌
			pstmt.setInt(1, no);

			pstmt.executeUpdate();

		}

	}

	// 리뷰 수정
	@Override
	public void updateReview(int no, String title, String content) throws SQLException {

		String sql = "UPDATE video_review SET review_title = ?, review_content = ? WHERE review_no = ?";
		try (
				// 데이터베이스 연결하기
				Connection con = dbUtil.getConnection(); // 연결-워크벤치 들어온 것과 같음
				PreparedStatement pstmt = con.prepareStatement(sql);

		)

		{
			// SQL문을 실행할 객체를 얻어온다. (연결 객체로부터)
			pstmt.setString(1, title);
			pstmt.setString(2, content);
			pstmt.setInt(3, no);

			pstmt.executeUpdate();

		}

	}

	// 리뷰수 카운트
	@Override
	public int countReview(String video_id) throws SQLException {
		String sql = "SELECT count(*) from video_review where review_id = ?  ";
		try (
				// 데이터베이스 연결하기
				Connection con = dbUtil.getConnection(); // 연결-워크벤치 들어온 것과 같음
				PreparedStatement pstmt = con.prepareStatement(sql);)

		{
			pstmt.setString(1, video_id);
			try (ResultSet rs = pstmt.executeQuery();) {
				if (rs.next()) {

					return rs.getInt(1);
				}
			}
		}
		return 0;
	}


	@Override
	public Review getReviewById(int reviewNo, String videoId) throws SQLException {
		Review review = null;
		DBUtil dbUtil = DBUtil.getInstance();
		String sql = "SELECT review_no, review_title, review_writer, review_content, review_id FROM video_review WHERE review_no = ? and review_id = ?";
		try (Connection con = dbUtil.getConnection(); PreparedStatement pstmt = con.prepareStatement(sql);) {
			pstmt.setInt(1, reviewNo);
			pstmt.setString(2, videoId);

			try (ResultSet rs = pstmt.executeQuery();) {
				if (rs.next()) {
					review = new Review();
					review.setReviewNo(rs.getInt("review_no"));
					review.setReviewTitle(rs.getString("review_title"));
					review.setReviewWriter(rs.getString("review_writer"));
					review.setReviewContent(rs.getString("review_content"));
					review.setReviewId(rs.getString("review_id"));
				}

				return review;
			}
		}
	}
	
}
