package video.model.service;

import java.util.List;

import video.model.dao.VideoDao;
import video.model.dao.VideoDaoImpl;
import video.model.dto.Video;

public class VideoServiceImpl implements VideoService {

	VideoDao videoDao;
	
	private static VideoService instance = new VideoServiceImpl();
	public VideoServiceImpl() {
		videoDao = VideoDaoImpl.getInstance();
	}
	public static VideoService getInstance() {
		return instance;
	}
	
	@Override
	public Video selectVideoById(String video_id) throws Exception {
		return videoDao.selectVideoById(video_id);
	}
	
	@Override
	public List<Video> selectAllVideos() throws Exception {
		return videoDao.selectAllVideos();
	}
	
	@Override
	public void updateViewCnt(String video_id) throws Exception {
		videoDao.updateViewCnt(video_id);
	}

}
