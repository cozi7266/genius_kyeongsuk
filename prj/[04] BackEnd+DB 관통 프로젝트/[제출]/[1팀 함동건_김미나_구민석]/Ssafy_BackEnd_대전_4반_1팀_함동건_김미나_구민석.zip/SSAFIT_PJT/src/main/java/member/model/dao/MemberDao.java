package member.model.dao;

import java.sql.SQLException;

import member.model.dto.Member;

public interface MemberDao {

	void insertMember(Member member) throws SQLException;

	Member selectMember(Member member) throws SQLException;

}
