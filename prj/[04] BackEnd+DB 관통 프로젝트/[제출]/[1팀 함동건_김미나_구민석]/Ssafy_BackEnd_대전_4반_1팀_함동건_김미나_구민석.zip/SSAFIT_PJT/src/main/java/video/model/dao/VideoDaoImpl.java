package video.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import db.utill.DBUtil;
import video.model.dto.Video;

public class VideoDaoImpl implements VideoDao {

	private static VideoDao instance = new VideoDaoImpl();

	private VideoDaoImpl() {
	}

	public static VideoDao getInstance() {
		return instance;
	}

	// DB유틸 객체 생성
	private DBUtil dbUtil = DBUtil.getInstance();

	public List<Video> selectAllVideos() throws SQLException {
		List<Video> videos = new ArrayList<>();
		String sql = "SELECT video_title, video_id, video_part, video_view, video_thumbnail FROM video";

		try (
				// 데이터베이스 연결하기
				Connection con = dbUtil.getConnection();
				// 실행할 SQL 문 작성
				// 아이디와 일치하는 비밀번호 가져오기
				// 가져와서 일치하는지 확인하기
				// SQL문을 실행할 객체를 얻어온다.
				PreparedStatement pstmt = con.prepareStatement(sql); )


		{
			
			try (
					
					// SQL문 실행하기 : select(executeQuery), select절 이외(executeUpdate)
					ResultSet rs = pstmt.executeQuery();
					){
				
				while (rs.next()) { // 결과 값이 있으면
					String video_title = rs.getString("video_title");
					String video_id = rs.getString("video_id");
					String video_part = rs.getString("video_part");
					int video_view = rs.getInt("video_view");
					String video_thumbnail = rs.getString("video_thumbnail");
					Video v = new Video();
					v.setVideoTitle(video_title);
					v.setVideoId(video_id);
					v.setVideoPart(video_part);
					v.setVideoView(video_view);
					v.setVideoThumbnail(video_thumbnail);
					videos.add(v);
				}
				return videos;
				
			}
		}

	}

	public Video selectVideoById(String id) throws SQLException {
		// 실행할 SQL문 작성
		String sql = "SELECT video_title, video_id, video_part, video_channel, video_url FROM video WHERE video_id = ?";

		try (
				// 어떤 걸 가져올지는 화면에 뭐 보여줄지에 따라서
				// 데이터베이스 연결하기
				Connection con = dbUtil.getConnection();
				// SQL문을 실행할 객체를 얻어온다. (연결 객체로부터)
				PreparedStatement pstmt = con.prepareStatement(sql);

		)

		{
			// SQL문을 실행 전에 ?에 값을 설정하자.
			pstmt.setString(1, id);
			
			try (
					
					ResultSet rs = pstmt.executeQuery(); // 접속해서 실행 한것(ctrl enter한거) select * 결과 들어있음
					) {
				
				
				// SQL문 실행하기 : select(executeQuery), select절 외에는 (executeUpdate)
				// 실행 결과를 받아서 (객체에 담아서 줌)
				// 데이터 마다(레코드)
				if (rs.next()) { // 위에서부터 내려가서 데이터 있으면 true 없으면 빠져나옴
					String video_title = rs.getString("video_title");
					String video_id = rs.getString("video_id");
					String video_part = rs.getString("video_part");
					String video_channel = rs.getString("video_channel");
					String video_url = rs.getString("video_url");
					Video v = new Video();
					v.setVideoTitle(video_title);
					v.setVideoId(video_id);
					v.setVideoPart(video_part);
					v.setVideoChannel(video_channel);
					v.setVideoUrl(video_url);
					
					return v;
				}
				
				return null; // 결과 없을 때
				
			}

		}

	}

	@Override
	public void updateViewCnt(String video_id) throws SQLException {
		String sql = "UPDATE video SET video_view = video_view + 1 WHERE video_id = ?";
		try (
				Connection con = dbUtil.getConnection();
				PreparedStatement pstmt = con.prepareStatement(sql);
		) {
			pstmt.setString(1, video_id);
			pstmt.executeUpdate();
		}
	}
}
