package review.model.dao;

import java.sql.SQLException;
import java.util.List;

import review.model.dto.Review;

public interface ReviewDao {
/*
 * 	// 해당 번호의 리뷰 수정
		reviewDao.updateReview(no, title, content);
 * 
 * 삭제
 * 	reviewDao.deleteReview(no)
 * 
 * 등록
 * 	reviewDao.insertReview(review);
 * 
 * 
 * 상세 조회
 * Review review = reviewService.detail(id);
 * */
	
	void insertReview(Review review) throws Exception;
	
	// 아이디에 해당하는 리뷰목록 
	List<Review> selectAllReviews(String video_id) throws Exception;
	
	void deleteReview(int no) throws Exception;
	
	
	void updateReview(int no, String title, String content) throws Exception;

	
	int countReview(String video_id) throws Exception;
	

	Review getReviewById(int reviewNo, String videoId) throws SQLException;
	
}
