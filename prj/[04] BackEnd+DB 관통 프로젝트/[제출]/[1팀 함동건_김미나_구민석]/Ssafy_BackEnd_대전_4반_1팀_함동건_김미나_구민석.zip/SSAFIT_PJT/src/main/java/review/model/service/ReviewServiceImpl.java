package review.model.service;

import java.sql.SQLException;
import java.util.List;

import review.model.dao.ReviewDao;
import review.model.dao.ReviewDaoImpl;
import review.model.dto.Review;

public class ReviewServiceImpl implements ReviewService {
	
	public ReviewDao reviewDao;
	
	// 싱글톤 패턴 
	private static ReviewService reviewService = new ReviewServiceImpl();
	public ReviewServiceImpl() {
		reviewDao = ReviewDaoImpl.getInstance();
	}
	public static ReviewService getInstance() {
		return reviewService;
	}

	@Override
	public void insertReview(Review review) throws Exception {
		reviewDao.insertReview(review);
		
	}

	@Override
	public void updateReview(int no, String title, String content) throws Exception {
		reviewDao.updateReview(no, title, content);
		
	}

	@Override
	public void deleteReview(int no) throws Exception {
		reviewDao.deleteReview(no);
		
	}

	@Override
	public List<Review> selectAllReviews(String video_id) throws Exception {
		return reviewDao.selectAllReviews(video_id);
	}
	@Override
	public int countReview(String video_id) throws Exception {
		
		return reviewDao.countReview(video_id);
	}
	
	@Override
	public Review getReviewById(int reviewNo, String videoId) throws Exception {
		return reviewDao.getReviewById(reviewNo, videoId);
	}
	
}
