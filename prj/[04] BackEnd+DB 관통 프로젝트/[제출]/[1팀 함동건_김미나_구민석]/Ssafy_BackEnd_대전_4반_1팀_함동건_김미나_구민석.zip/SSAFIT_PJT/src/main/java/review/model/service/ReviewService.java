package review.model.service;

import java.util.List;

import review.model.dto.Review;

public interface ReviewService {
	
	// 리뷰 등록 
	void insertReview(Review review) throws Exception;
	
	// 리뷰 수정 
	void updateReview(int no, String title, String content) throws Exception;
	
	// 리뷰 삭제 
	void deleteReview(int no) throws Exception;
	
	// 리뷰 조회 
	List<Review> selectAllReviews(String video_id) throws Exception;

	int countReview(String video_id) throws Exception;
	
	Review getReviewById(int reviewNo, String videoId) throws Exception;
	
}
