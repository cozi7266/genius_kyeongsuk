package board.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import review.model.dto.Review;
import review.model.service.ReviewService;
import review.model.service.ReviewServiceImpl;
import video.model.dao.VideoDao;
import video.model.dao.VideoDaoImpl;
import video.model.dto.Video;
import video.model.service.VideoService;
import video.model.service.VideoServiceImpl;

@WebServlet("/board")
public class BoardController extends HttpServlet{
	// 리뷰 관련 기능 
	
	// 사용할 reviewService 객체 만들기
	private ReviewService reviewService; 
	private VideoService videoService;
	public BoardController() {
		reviewService = ReviewServiceImpl.getInstance();
		videoService = VideoServiceImpl.getInstance();
	}
	
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			String action = req.getParameter("action");
			
			if ("list".equals(action)) {
				// 영상 & 리뷰 정보 조회
				doList(req, resp);
			} else if ("write".equals(action)) {
				// 리뷰 등록
				doWrite(req, resp);
			}else if ("update".equals(action)) {
				// 리뷰 수정
				// -> 리뷰 작성 폼에 리뷰 정보가 value로 들어가고 add했을때 기존 정보가 업데이트됨
				doUpdate(req, resp);
			} else if ("remove".equals(action)) {
				// 리뷰 삭제
				doRemove(req, resp);
			} else if ("edit".equals(action)) {
				// 수정폼으로 이동
				doEdit(req, resp);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new ServletException(e);
		}
	}

	
	// 수정 폼으로 이동
	private void doEdit(HttpServletRequest req, HttpServletResponse resp) throws Exception {
		System.out.println("수정 요청");
		
		String videoId = req.getParameter("review_id");
		int reviewNo = Integer.parseInt(req.getParameter("review_no"));

		Review review = reviewService.getReviewById(reviewNo, videoId);
		req.setAttribute("editReview", review);
		///////////////////////////////////////
		

		Video video = videoService.selectVideoById(videoId);
		req.setAttribute("video", video); // 정보 등록해줌

		HttpSession session = req.getSession();
		String currentUserId = (String) session.getAttribute("memberInfo.userId");
		req.setAttribute("currentUserId", currentUserId);

		///////////////////////////////////////////
		RequestDispatcher rd = req.getRequestDispatcher("/jsp/editForm.jsp");
		rd.forward(req, resp);
		
		
	}
	
	
	// 리뷰 수정
	private void doUpdate(HttpServletRequest req, HttpServletResponse resp) throws Exception {
		// 리뷰 번호 받기
		
		
		// 리뷰 번호의 정보 가져와서 작성폼에 띄우기
		// 작성폼에서 리뷰 수정 요청했는지 검사하기 
		
		
		
		int review_no = Integer.parseInt(req.getParameter("review_no"));
		
		String title = req.getParameter("review_title");
		String content = req.getParameter("review_content");
		
		// 해당 번호의 리뷰 수정
		reviewService.updateReview(review_no, title, content);
		
		String review_id = req.getParameter("review_id"); // 영상 아이디 
		resp.sendRedirect(req.getContextPath() + "/board?action=list&video_id=" + review_id);		
	}

	// 리뷰 삭제 
	private void doRemove(HttpServletRequest req, HttpServletResponse resp) throws Exception {
		System.out.println("삭제");
		// 리뷰 번호 받기
		int review_no = Integer.parseInt(req.getParameter("review_no")); // 삭제할 리뷰 번호 
		reviewService.deleteReview(review_no);
		
		
		String review_id = req.getParameter("review_id"); // 영상 아이디 
		resp.sendRedirect(req.getContextPath() + "/board?action=list&video_id=" + review_id);
	}

	// 리뷰 작성 
	private void doWrite(HttpServletRequest req, HttpServletResponse resp) throws Exception {

		// 로그인 했으면 리뷰 등록
		String video_id = req.getParameter("video_id");
		String title = req.getParameter("review_title");
		String content = req.getParameter("review_content");
		
		Review review = new Review();
		review.setReviewTitle(title);
		review.setReviewContent(content);
		review.setReviewId(video_id);
		
		// 작성자 정보 가져와서 저장
		String member_id = req.getParameter("member_id");
		review.setReviewWriter(member_id);
		
		
		// 리뷰 등록
		reviewService.insertReview(review);
		
		resp.sendRedirect(req.getContextPath() + "/board?action=list&video_id=" + video_id);

		
	}

	// 리뷰 조회 , 영상 조회
	private void doList(HttpServletRequest req, HttpServletResponse resp) throws Exception {
		// 영상클릭했을때 영상 아이디를 받아와서
		// 아이디에 해당하는 영상정보 보여주고
		// 아이디에 해당하는 리뷰목록 보여주고
		// 리뷰 작성폼도 보여줌 - 프론트에 있음
		
		// 영상 id 가져옴
		String video_id = req.getParameter("video_id"); // video id
		// id에 해당하는 영상정보 가져오기
		
		
		// 영상 글 조회수 업데이트
		videoService.updateViewCnt(video_id);
		
		
		Video video = videoService.selectVideoById(video_id);
		req.setAttribute("video", video); // 정보 등록해줌
		
		// 리뷰정보도 가져오기 -> DB에 저장된 리뷰를 가져와서jsp에서 보여주기
		// 아이디에 해당하는 리뷰목록 
		List<Review> reviewList = reviewService.selectAllReviews(video_id);
		req.setAttribute("reviewList", reviewList); // 리뷰 정보 등록해줌
		
		
		// 상세 페이지로 이동
		RequestDispatcher rd = req.getRequestDispatcher("/jsp/review.jsp");
		rd.forward(req, resp);
	}
	
	
	   
	
}
