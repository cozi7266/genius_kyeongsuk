package member.controller;

import java.io.IOException;
import java.sql.SQLException;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import member.model.dto.Member;
import member.model.service.MemberService;
import member.model.service.MemberServiceImpl;

@WebServlet("/member")
public class MemberController extends HttpServlet {
	
	private MemberService memberService;
	public MemberController() {
		memberService = MemberServiceImpl.getInstance();
	}

	
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		try {
			String action = req.getParameter("action");
			if ("join".equals(action)) {
				// 회원 가입 
				join(req, resp);
			} else if ("joinForm".equals(action)) {
				// 회원가입창 이동 
				joinForm(req, resp);
			} else if ("loginForm".equals(action)) {
				// 로그인 창 
				loginForm(req, resp);
			} else if ("login".equals(action)) {
				// 로그인  
				login(req, resp);
			} else if ("logout".equals(action)) {
				// 로그아웃 
				logout(req, resp);
			} 
			
		} catch (Exception e) {
			e.printStackTrace();
			throw new ServletException(e);
		}
	}
	
	private void logout(HttpServletRequest req, HttpServletResponse resp) throws Exception {
		HttpSession session = req.getSession(false);
		
		
		if (session != null) {
			session.invalidate(); 
		}
		resp.sendRedirect(req.getContextPath() + "/main");
	}

	private void login(HttpServletRequest req, HttpServletResponse resp) throws Exception {
		String id = req.getParameter("id");
		String password = req.getParameter("password");
		Member param = new Member();
		param.setUserId(id);
		param.setUserPassword(password);
		// member가 null일 경우 : id 또는 password 가 틀린 경우 - 로그인 실패
		// null이 아닐 경우 : 로그인 성공
		Member member = memberService.selectMember(param);
		String path = "/member?action=loginForm";
		if (member != null) {  // 로그인 성공 : 로그인 상태를 저장하자
			path = "/main";
			HttpSession session = req.getSession();
			session.setAttribute("memberInfo", member);
			

		    // 로그로 확인
		    System.out.println("로그인 성공: " + member.getUserName() + "님이 로그인했습니다.");
		}
		resp.sendRedirect(req.getContextPath() + path);
	}

	private void loginForm(HttpServletRequest req, HttpServletResponse resp) throws Exception {
		RequestDispatcher rd = req.getRequestDispatcher("/jsp/authentication-login.jsp");
		rd.forward(req, resp);
	}

	private void joinForm(HttpServletRequest req, HttpServletResponse resp) throws Exception {
		// /member?action=joinForm
		// /member/join.jsp 이동해야 한다.
		RequestDispatcher rd = req.getRequestDispatcher("/jsp/authentication-register.jsp");
		rd.forward(req, resp);
	}

	/**
	 * 회원가입 처리
	 * @param req
	 * @param resp
	 * @throws ServletException
	 * @throws IOException
	 * @throws SQLException 
	 */
	private void join(HttpServletRequest req, HttpServletResponse resp) throws Exception {
		String id = req.getParameter("id");
		String name = req.getParameter("name");
		String password = req.getParameter("password");
		Member member = new Member(id, name, password);
		System.out.println(name + "님이 회원가입하셨습니다.");
		memberService.insertMember(member);
		
		resp.sendRedirect(req.getContextPath() + "/member?action=loginForm");
	}
	
	
}
