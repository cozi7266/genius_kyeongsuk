package video.model.dto;

public class Video {
	private String videoId;
	private String videoTitle;
	private String videoUrl;
	private int videoView;
	private int videoReviewCnt;
	private String videoPart;
	private String videoChannel;
	private String videoThumbnail;
	
	public Video() {}

	public Video(String videoId, String videoTitle, String videoUrl, int videoView, int videoReviewCnt,
			String videoPart, String videoChannel, String videoThumbnail) {
		super();
		this.videoId = videoId;
		this.videoTitle = videoTitle;
		this.videoUrl = videoUrl;
		this.videoView = videoView;
		this.videoReviewCnt = videoReviewCnt;
		this.videoPart = videoPart;
		this.videoChannel = videoChannel;
		this.videoThumbnail = videoThumbnail;
	}

	public String getVideoId() {
		return videoId;
	}

	public void setVideoId(String videoId) {
		this.videoId = videoId;
	}

	public String getVideoTitle() {
		return videoTitle;
	}

	public void setVideoTitle(String videoTitle) {
		this.videoTitle = videoTitle;
	}

	public String getVideoUrl() {
		return videoUrl;
	}

	public void setVideoUrl(String videoUrl) {
		this.videoUrl = videoUrl;
	}

	public int getVideoView() {
		return videoView;
	}

	public void setVideoView(int videoView) {
		this.videoView = videoView;
	}

	public int getVideoReviewCnt() {
		return videoReviewCnt;
	}

	public void setVideoReviewCnt(int videoReviewCnt) {
		this.videoReviewCnt = videoReviewCnt;
	}

	public String getVideoPart() {
		return videoPart;
	}

	public void setVideoPart(String videoPart) {
		this.videoPart = videoPart;
	}

	public String getVideoChannel() {
		return videoChannel;
	}

	public void setVideoChannel(String videoChannel) {
		this.videoChannel = videoChannel;
	}

	public String getVideoThumbnail() {
		return videoThumbnail;
	}

	public void setVideoThumbnail(String videoThumbnail) {
		this.videoThumbnail = videoThumbnail;
	}

	@Override
	public String toString() {
		return "Video [videoId=" + videoId + ", videoTitle=" + videoTitle + ", videoUrl=" + videoUrl + ", videoView="
				+ videoView + ", videoReviewCnt=" + videoReviewCnt + ", videoPart=" + videoPart + ", videoChannel="
				+ videoChannel + ", videoThumbnail=" + videoThumbnail + "]";
	}
	
}
