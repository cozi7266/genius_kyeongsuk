package main.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import review.model.service.ReviewService;
import review.model.service.ReviewServiceImpl;
import video.model.dto.Video;
import video.model.service.VideoService;
import video.model.service.VideoServiceImpl;

@WebServlet("/main")
public class MainController extends HttpServlet {
	private ReviewService reviewService; 
	private VideoService videoService;
	public MainController() {
		reviewService = ReviewServiceImpl.getInstance();
		videoService = VideoServiceImpl.getInstance();
	}
	
	
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
	    List<Video> videoList = null;
	    
		try {
			videoList = videoService.selectAllVideos();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		// 리뷰 수 가져오기
		for (Video v : videoList) {
			String video_id = v.getVideoId();
			try {
				v.setVideoReviewCnt(reviewService.countReview(video_id));
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

        req.setAttribute("videoList", videoList);
		
		RequestDispatcher rd = req.getRequestDispatcher("/main/main.jsp"); // 이동할 주소(/ 현재 프로젝트 경로부터, 프로젝트명은 알아서 붙여줌)
		rd.forward(req, resp);

	}

}
