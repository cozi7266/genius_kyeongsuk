package member.model.service;

import member.model.dao.MemberDao;
import member.model.dao.MemberDaoImpl;
import member.model.dto.Member;

public class MemberServiceImpl implements MemberService {
	
	MemberDao memberDao;
	
	private static MemberService instance = new MemberServiceImpl();
	private MemberServiceImpl() {
		memberDao = MemberDaoImpl.getInstance();
	}
	public static MemberService getInstance() {
		return instance;
	}
	@Override
	public Member selectMember(Member param) throws Exception {
		return memberDao.selectMember(param);
	}
	@Override
	public void insertMember(Member member) throws Exception {
		memberDao.insertMember(member);
	}
	
}
