package video.model.dao;

import java.sql.SQLException;
import java.util.List;

import video.model.dto.Video;

public interface VideoDao {

	public List<Video> selectAllVideos() throws SQLException;
	
	public Video selectVideoById(String id) throws SQLException;

	public void updateViewCnt(String video_id) throws SQLException;
	
}
