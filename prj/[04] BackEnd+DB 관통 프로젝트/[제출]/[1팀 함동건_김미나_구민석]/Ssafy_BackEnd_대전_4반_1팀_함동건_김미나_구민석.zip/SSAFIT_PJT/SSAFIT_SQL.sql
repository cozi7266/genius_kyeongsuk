use ssafitdb;



drop table video_review;
drop table video;
drop table member;

CREATE TABLE member (
	user_id VARCHAR(200) NOT NULL,
	user_password VARCHAR(200) NOT NULL,
	user_name VARCHAR(30) NOT NULL,
    PRIMARY KEY(user_id)
);

CREATE TABLE video (
	video_id VARCHAR(100) NOT NULL,	
	video_title VARCHAR(200) NOT NULL,
	video_url VARCHAR(1000) NOT NULL,
	video_view INT NOT NULL DEFAULT 0,
	video_part VARCHAR(100) NOT NULL,
	video_channel VARCHAR(200) NOT NULL,
    video_thumbnail VARCHAR(200) NOT NULL,
	PRIMARY KEY(video_id)
);

CREATE TABLE video_review (
	review_no INT NOT NULL AUTO_INCREMENT,
    review_title VARCHAR(200) NOT NULL,
    review_writer VARCHAR(200) NOT NULL,
    review_content VARCHAR(1000) NOT NULL,
    review_id VARCHAR(100) NOT NULL,
    reg_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (review_no),
    FOREIGN KEY (review_writer) REFERENCES member(user_id) on delete CASCADE,
    FOREIGN KEY (review_id) REFERENCES video(video_id) on delete CASCADE
);


select * from video;
select * from video_review;
select * from member;


insert into video (video_id, video_title, video_url, video_part, video_channel, video_thumbnail)
values ("video1", "Shim EuDdeum 10 Minute Morning Stretch Everydayㅣ2023 Renewal", "50WCSpZtdmA?si=Hj9GPxwN25BInD5h", "전신", "힙으뜸" , "work1.png"),
("video2", "하루 두 번🧘🏻‍♀️반드시 해야하는 20분 전신순환 스트레칭 Ep.08", "Kk7TQGqQ3nA?si=ZfHW53BgByvekSml", "전신","빵느", "work2.png"),
("video3", "15 MIN Fat Burning Cardio - 서서하는 유산소 - 다이어트 운동", "02K-k6daPb4?si=DXo7GQSWTk9d3U1M", "전신","빅씨스 Bigsis", "work3.png"),
("video4", "뭉친 어깨, 뻣뻣한 골반 풀어주는 요가 | 앉아서 하는 요가 스트레칭 | 어깨 근육 풀기, 골반풀기", "D3yExRi7EME?si=PSj-OM2hzJMQesiQ", "상체","Mindful Yoga with Eileen", "work4.png");

insert into member (user_id, user_password, user_name)
values ("ssafy", "1234", "김싸피");

insert into video_review (review_title, review_writer, review_content, review_id)
values ("테스트", "ssafy", "리뷰 작성 테스트", "video1");

select count(*) from video_review where review_id = "video1";