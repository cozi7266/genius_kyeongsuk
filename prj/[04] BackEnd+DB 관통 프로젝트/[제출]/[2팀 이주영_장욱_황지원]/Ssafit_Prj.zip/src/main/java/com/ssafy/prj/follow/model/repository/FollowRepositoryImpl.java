package com.ssafy.prj.follow.model.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ssafy.prj.member.model.dto.Member;
import com.ssafy.prj.util.DBUtil;

public class FollowRepositoryImpl implements FollowRepository {
	private DBUtil dbUtil;
	
	private FollowRepositoryImpl() {
		dbUtil = DBUtil.getInstance();
	}
	private static FollowRepository instance = new FollowRepositoryImpl();
	public static FollowRepository getInstance() {
		return instance;
	}
	
	// 팔로우 목록에 추가
	@Override
	public void insertFollow(Member m1, Member m2) throws Exception {
		String sql = "INSERT INTO follow(followed_id, following_id) VALUES(?, ?)";
		
		try(
				Connection con = dbUtil.getConnection();
				PreparedStatement pstmt = con.prepareStatement(sql);
		   ) 
		{
			pstmt.setString(1, m2.getId());
			pstmt.setString(2, m1.getId());
			
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	// 팔로우 목록에서 하나 삭제
	@Override
	public void deleteFollow(Member m1, Member m2) throws Exception {
		String sql = "DELETE FROM follow WHERE following_id = ? AND followed_id = ?";
		
		try(
				Connection con = dbUtil.getConnection();
				PreparedStatement pstmt = con.prepareStatement(sql);
		   ) 
		{
			pstmt.setString(1, m1.getId());
			pstmt.setString(2, m2.getId());
			
			pstmt.executeUpdate();
		}
	}
	
	// 팔로우 목록에서 전체 삭제
	@Override
	public void deleteAll(Member member) throws Exception {
		String sql = "DELETE FROM follow WHERE following_id = ?";
		
		try(
				Connection con = dbUtil.getConnection();
				PreparedStatement pstmt = con.prepareStatement(sql);
		   ) 
		{
			pstmt.setString(1, member.getId());
			
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	// 팔로우 목록에 이미 있는 사람인지 검사
	@Override
	public boolean isFollowed(Member m1, Member m2) throws Exception {
		String sql = "SELECT followed_id FROM follow WHERE following_id = ?";
		
		try(
				Connection con = dbUtil.getConnection();
				PreparedStatement pstmt = con.prepareStatement(sql);
		   ) 
		{
			pstmt.setString(1, m1.getId());
			
			ResultSet rs = pstmt.executeQuery();
			
			while (rs.next()) {
				if (m2.getId().equals(rs.getString("followed_id"))) {
					return true;
				}
			}
		}
		return false;
	}
	
	// 팔로우 목록 조회
	@Override
	public List<String> selectFollow(Member member) throws Exception {
		List<String> list = new ArrayList<>();
		
		String sql = "SELECT followed_id From follow WHERE following_id = ?";
		
		try(
				Connection con = dbUtil.getConnection();
				PreparedStatement pstmt = con.prepareStatement(sql);
		   ) 
		{
			pstmt.setString(1, member.getId());
			
			ResultSet rs = pstmt.executeQuery();
			
			while (rs.next()) {
				list.add(rs.getString("followed_id"));
			}
			return list;
		}
	}
}
