package com.ssafy.prj.video.model.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ssafy.prj.util.DBUtil;
import com.ssafy.prj.video.model.dto.Video;

public class VideoRepositoryImpl implements VideoRepository {
	private DBUtil dbUtil;
	private VideoRepositoryImpl() {
		dbUtil = DBUtil.getInstance();
	}
	private static VideoRepository instance = new VideoRepositoryImpl();
	public static VideoRepository getInstance() {
		return instance;
	}
	
	// 전체 비디오 조회
	@Override
	public List<Video> selectVideo() throws Exception {
		List<Video> list = new ArrayList<>();
		
		String sql = "SELECT * FROM video";
		
		try(
				Connection con = dbUtil.getConnection();
				PreparedStatement pstmt = con.prepareStatement(sql);
		   ) 
		{
			ResultSet rs = pstmt.executeQuery();
			
			while(rs.next()) {
				Video video = new Video();
				video.setVideoNo(rs.getInt("video_no"));
				video.setVideoName(rs.getString("video_name"));
				video.setUrl(rs.getString("url"));
				video.setImage(rs.getString("image"));
				video.setPart(rs.getString("part"));
				video.setChannelName(rs.getString("channel_name"));
				video.setViewCnt(rs.getInt("view_cnt"));
				
				list.add(video);
			}
			
			return list;
		}
	}
	
	// 핫 비디오 6개
	@Override
	public List<Video> selectHotVideo() throws Exception {
		List<Video> list = new ArrayList<>();
		
		String sql = "SELECT * FROM video ORDER BY view_cnt DESC LIMIT 6";
		
		try(
				Connection con = dbUtil.getConnection();
				PreparedStatement pstmt = con.prepareStatement(sql);
		   ) 
		{
			ResultSet rs = pstmt.executeQuery();
			
			while (rs.next()) {
				Video video = new Video();
				video.setVideoNo(rs.getInt("video_no"));
				video.setVideoName(rs.getString("video_name"));
				video.setUrl(rs.getString("url"));
				video.setImage(rs.getString("image"));
				video.setPart(rs.getString("part"));
				video.setChannelName(rs.getString("channel_name"));
				video.setViewCnt(rs.getInt("view_cnt"));
				
				list.add(video);
			}
			return list;
		}
	}
	
	// 비디오 조회수 증가
	@Override
	public void updateVideoViewCnt(int no) throws Exception {
		String sql = "UPDATE video SET view_cnt = view_cnt + 1 WHERE video_no = ?";
		
		try(
				Connection con = dbUtil.getConnection();
				PreparedStatement pstmt = con.prepareStatement(sql);
		   ) 
		{
			pstmt.setInt(1, no);
			
			pstmt.executeUpdate();
		}
	}
	
	// 비디오 하나 조회
	@Override
	public Video selectVideoByNo(int no) throws Exception {
		String sql = "SELECT * FROM video WHERE video_no = ?";
		
		try(
				Connection con = dbUtil.getConnection();
				PreparedStatement pstmt = con.prepareStatement(sql);
		   ) 
		{
			pstmt.setInt(1, no);
			
			ResultSet rs = pstmt.executeQuery();
			
			Video tmp = new Video();
			
			while (rs.next()) {
				tmp.setVideoNo(Integer.parseInt(rs.getString("video_no")));
				tmp.setVideoName(rs.getString("video_name"));
				tmp.setUrl(rs.getString("url"));
				tmp.setImage(rs.getString("image"));
				tmp.setPart(rs.getString("part"));
				tmp.setChannelName(rs.getString("channel_name"));
				tmp.setViewCnt(rs.getInt("view_cnt"));
			}
			return tmp;
		}
	}
}
