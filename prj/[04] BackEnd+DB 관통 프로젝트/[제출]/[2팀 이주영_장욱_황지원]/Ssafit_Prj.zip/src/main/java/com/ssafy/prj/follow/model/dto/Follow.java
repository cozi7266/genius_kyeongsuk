package com.ssafy.prj.follow.model.dto;

public class Follow {

}
