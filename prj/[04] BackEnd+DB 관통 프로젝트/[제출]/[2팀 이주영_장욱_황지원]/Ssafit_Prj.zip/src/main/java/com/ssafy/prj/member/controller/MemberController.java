package com.ssafy.prj.member.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import com.ssafy.prj.follow.model.service.FollowService;
import com.ssafy.prj.follow.model.service.FollowServiceImpl;
import com.ssafy.prj.likelist.model.dto.Likelist;
import com.ssafy.prj.likelist.model.service.LikelistService;
import com.ssafy.prj.likelist.model.service.LikelistServiceImpl;
import com.ssafy.prj.member.model.dto.Member;
import com.ssafy.prj.member.model.repository.MemberRepository;
import com.ssafy.prj.member.model.repository.MemberRepositoryImpl;
import com.ssafy.prj.member.model.service.MemberService;
import com.ssafy.prj.member.model.service.MemberServiceImpl;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/member")
public class MemberController extends HttpServlet{
	
	private MemberService memberService;
	private FollowService followService;
	private LikelistService likelistService;
	public MemberController() {
	    memberService = MemberServiceImpl.getInstance();
	    followService = FollowServiceImpl.getInstance();
	    likelistService = LikelistServiceImpl.getInstance();
	}
	
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			String action = req.getParameter("action");
			switch (action) {
				case "joinForm": {
					joinForm(req, resp);
					break;
				}
				case "join": {
					join(req, resp);
					break;
				}
				case "loginForm": {
					loginForm(req, resp);
					break;
				}
				case "login": {
					login(req, resp);
					break;
				}
				case "logout": {
					logout(req, resp);
					break;
				}
				case "mypage": {
					mypage(req, resp);
					break;
				}
				default: {
					
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new ServletException(e);
		}
	}


	private void mypage(HttpServletRequest req, HttpServletResponse resp) throws Exception {
		HttpSession session = req.getSession();
		Member member = (Member) session.getAttribute("memberInfo");
		
		List<String> follow = followService.FollowingList(member);
		List<String> likelist = likelistService.Likelist(member);
		
		req.setAttribute("likelist", likelist);
		req.setAttribute("followList", follow);
		
		req.getRequestDispatcher("/WEB-INF/member/mypage.jsp").forward(req, resp);
	}

	private void logout(HttpServletRequest req, HttpServletResponse resp) throws Exception {
		HttpSession session = req.getSession();
		session.invalidate();
		resp.sendRedirect(req.getContextPath()+"/main");
	}

	private void login(HttpServletRequest req, HttpServletResponse resp) throws Exception {
		String id = req.getParameter("id");
		String password = req.getParameter("password");
		
		Member tmp = new Member();
		tmp.setId(id);
		tmp.setPassword(password);
		Member member = new Member();
		try {
			member = memberService.login(tmp);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		String path = "/member?action=loginForm";  
		if(member != null) { // 로그인 성공
			path = "/main";
			HttpSession session = req.getSession();
			session.setAttribute("memberInfo", member);
		}
		
		resp.sendRedirect(req.getContextPath()+ path);
	}

	private void loginForm(HttpServletRequest req, HttpServletResponse resp) throws Exception {
		req.getRequestDispatcher("/WEB-INF/member/login.jsp").forward(req, resp);
	}

	private void join(HttpServletRequest req, HttpServletResponse resp) throws Exception {
		String id = req.getParameter("id");
		String name = req.getParameter("name");
		String email = req.getParameter("email");
		String password = req.getParameter("password");
		
		Member member = new Member(id, name, email, password);
		try {
			memberService.join(member);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		resp.sendRedirect(req.getContextPath()+"/member?action=loginForm");
	}

	private void joinForm(HttpServletRequest req, HttpServletResponse resp) throws Exception {
		req.getRequestDispatcher("/WEB-INF/member/join.jsp").forward(req, resp);
	}
}
