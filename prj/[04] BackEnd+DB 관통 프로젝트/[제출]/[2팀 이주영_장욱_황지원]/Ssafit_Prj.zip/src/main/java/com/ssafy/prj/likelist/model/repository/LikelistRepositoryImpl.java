package com.ssafy.prj.likelist.model.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.ssafy.prj.member.model.dto.Member;
import com.ssafy.prj.util.DBUtil;
import com.ssafy.prj.video.model.dto.Video;

public class LikelistRepositoryImpl implements LikelistRepository {
	private DBUtil dbUtil;
	private LikelistRepositoryImpl() {
		dbUtil = DBUtil.getInstance();
	}
	private static LikelistRepository instance = new LikelistRepositoryImpl();
	public static LikelistRepository getInstance() {
		return instance;
	}
	
	// 찜 목록에 추가
	@Override
	public void insertLikelist(Video video, Member member) throws Exception {
		String sql = "INSERT INTO like_list(id, like_video) VALUES(?, ?)";
		
		try(
				Connection con = dbUtil.getConnection();
				PreparedStatement pstmt = con.prepareStatement(sql);
		   ) 
		{
			pstmt.setString(1, member.getId());
			pstmt.setString(2, video.getVideoName());
			
			pstmt.executeUpdate();
		}
	}
	
	// 찜 목록에서 하나 삭제
	@Override
	public void deleteLikelistByVideoNo(Video video, Member member) throws Exception {
		String sql = "DELETE FROM like_list WHERE id = ? AND like_video = ?";
		
		try(
				Connection con = dbUtil.getConnection();
				PreparedStatement pstmt = con.prepareStatement(sql);
		   ) 
		{
			pstmt.setString(1, member.getId());
			pstmt.setString(2, video.getVideoName());
			
			pstmt.executeUpdate();
		}
	}
	
	// 찜 목록 전체 삭제
	@Override
	public void deleteLikelist(Member member) throws Exception {
		String sql = "DELETE FROM like_list WHERE id = ?";
		
		try(
				Connection con = dbUtil.getConnection();
				PreparedStatement pstmt = con.prepareStatement(sql);
		   ) 
		{
			pstmt.setString(1, member.getId());
			
			pstmt.executeUpdate();
		}
	}
	
	// 찜 목록에 있는 항목인지 검사 => 생각 좀 더 해봐봐
	@Override
	public boolean isInLikelist(Video video, Member member) throws Exception {
		String sql = "SELECT like_video FROM like_list WHERE id = ?";
		
		try(
				Connection con = dbUtil.getConnection();
				PreparedStatement pstmt = con.prepareStatement(sql);
		   ) 
		{
			pstmt.setString(1, member.getId());
			
			ResultSet rs = pstmt.executeQuery();
			
			while (rs.next()) {
				if (video.getVideoName().equals(rs.getString("like_video"))) {
					return true;
				}
			}
		}
		return false;
	}
	
	// 찜목록 조회
	@Override
	public List<String> readLikelist(Member member) throws Exception {
		List<String> list = new ArrayList<>();
		
		String sql = "SELECT like_video FROM like_list WHERE id = ?";
		
		try(
				Connection con = dbUtil.getConnection();
				PreparedStatement pstmt = con.prepareStatement(sql);
		   ) 
		{
			pstmt.setString(1, member.getId());
			
			ResultSet rs = pstmt.executeQuery();
			
			while (rs.next()) {
				list.add(rs.getString("like_video"));
			}
			
			return list;
		}
	}
}