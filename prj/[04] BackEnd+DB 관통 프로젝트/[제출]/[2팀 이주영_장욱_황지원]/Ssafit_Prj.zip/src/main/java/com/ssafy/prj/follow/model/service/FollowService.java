package com.ssafy.prj.follow.model.service;

import java.util.List;

import com.ssafy.prj.member.model.dto.Member;

public interface FollowService {

	// 팔로우 목록에 추가
	boolean addFollow(Member m1, Member m2) throws Exception;

	// 팔로우 목록에서 제거
	void stopFollow(Member m1, Member m2) throws Exception;

	// 팔로우 목록 전체 제거
	void stopFollowAll(Member member) throws Exception;

	// 팔로우 목록 리스트
	List<String> FollowingList(Member member) throws Exception;

}