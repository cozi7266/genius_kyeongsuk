package com.ssafy.prj.video.service;

import java.util.ArrayList;
import java.util.List;

import com.ssafy.prj.video.model.dto.Video;
import com.ssafy.prj.video.model.repository.VideoRepository;
import com.ssafy.prj.video.model.repository.VideoRepositoryImpl;

public class VideoServiceImpl implements VideoService {

	private VideoRepository videoRepository;

	private VideoServiceImpl() {
		videoRepository = VideoRepositoryImpl.getInstance();
	}

	private static VideoService instance = new VideoServiceImpl();

	public static VideoService getInstance() {
		return instance;
	}

	// 비디오 상세 조회
	@Override
	public Video detailVideo(int no) throws Exception {
		videoRepository.updateVideoViewCnt(no);
		
		Video video = videoRepository.selectVideoByNo(no);
		
		return video;
	}

	// 핫 비디오 6개
	@Override
	public List<Video> hotVideo() throws Exception {
		List<Video> list = new ArrayList<>();

		list = videoRepository.selectHotVideo();

		return list;
	}

	// 전체 비디오 조회
	@Override
	public List<Video> videoList() throws Exception {
		List<Video> list = new ArrayList<>();

		list = videoRepository.selectVideo();

		return list;
	}
}
