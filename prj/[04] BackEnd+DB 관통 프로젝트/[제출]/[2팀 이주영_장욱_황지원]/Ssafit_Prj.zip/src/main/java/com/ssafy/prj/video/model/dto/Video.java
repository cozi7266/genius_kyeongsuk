package com.ssafy.prj.video.model.dto;

public class Video {
	private int videoNo;
	private String videoName;
	private String url;
	private String image;
	private String part;
	private String channelName;
	private int viewCnt;
	
	public Video() {}
	public Video(int videoNo, String videoName, String url, String image, String part, String channelName, int viewCnt) {
		this.videoNo = videoNo;
		this.videoName = videoName;
		this.url = url;
		this.image = image;
		this.part = part;
		this.channelName = channelName;
		this.viewCnt = viewCnt;
	}
	public int getVideoNo() {
		return videoNo;
	}
	public void setVideoNo(int videoNo) {
		this.videoNo = videoNo;
	}
	public String getVideoName() {
		return videoName;
	}
	public void setVideoName(String videoName) {
		this.videoName = videoName;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getPart() {
		return part;
	}
	public void setPart(String part) {
		this.part = part;
	}
	public String getChannelName() {
		return channelName;
	}
	public void setChannelName(String channelName) {
		this.channelName = channelName;
	}
	public int getViewCnt() {
		return viewCnt;
	}
	public void setViewCnt(int viewCnt) {
		this.viewCnt = viewCnt;
	}
	@Override
	public String toString() {
		return "Board [videoNo=" + videoNo + ", videoName=" + videoName + ", url=" + url + ", image=" + image
				+ ", part=" + part + ", channelName=" + channelName + ", viewCnt=" + viewCnt + "]";
	}
}
