package com.ssafy.prj.follow.controller;

import java.io.IOException;

import com.ssafy.prj.follow.model.service.FollowService;
import com.ssafy.prj.follow.model.service.FollowServiceImpl;
import com.ssafy.prj.member.model.dto.Member;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/follow")
public class FollowController extends HttpServlet {
	
	private FollowService followService;
	public FollowController() {
		followService = FollowServiceImpl.getInstance();
	}
	
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			String action = req.getParameter("action");
			
			if ("follow".equals(action)) {
				follow(req, resp);
			} else if ("unFollow".equals(action)) {
				unFollow(req, resp);
			} else if ("clearFollow".equals(action)) {
				clearFollow(req, resp);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new ServletException();
		}
	}

	private void clearFollow(HttpServletRequest req, HttpServletResponse resp) throws Exception {
		HttpSession session = req.getSession();
		Member member = (Member) session.getAttribute("memberInfo");
		
		followService.stopFollowAll(member);

		resp.sendRedirect(req.getContextPath() + "/member?action=mypage");
	}

	private void unFollow(HttpServletRequest req, HttpServletResponse resp) throws Exception {
		HttpSession session = req.getSession();
		Member m1 = (Member) session.getAttribute("memberInfo");
		
		Member m2 = new Member();
		m2.setId(req.getParameter("id"));
		
		followService.stopFollow(m1, m2);
		
		resp.sendRedirect(req.getContextPath() + "/member?action=mypage");
	}

	private void follow(HttpServletRequest req, HttpServletResponse resp) throws Exception {
		HttpSession session = req.getSession();
		Member m1 = (Member) session.getAttribute("memberInfo");
		
		Member m2 = new Member();
		m2.setId(req.getParameter("writer"));
		
		boolean isFollowd = followService.addFollow(m1, m2);
		
		resp.sendRedirect(req.getContextPath() + "/member?action=mypage");
	}
}
