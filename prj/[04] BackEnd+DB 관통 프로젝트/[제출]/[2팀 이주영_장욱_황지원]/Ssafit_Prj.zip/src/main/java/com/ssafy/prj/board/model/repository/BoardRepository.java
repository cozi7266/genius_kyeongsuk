package com.ssafy.prj.board.model.repository;

import java.util.List;

import com.ssafy.prj.board.model.dto.Board;

public interface BoardRepository {

	// 등록
	void insertBoard(Board board) throws Exception;

	// 수정
	void updateBoard(Board board) throws Exception;

	// 삭제
	void deleteBoard(int no) throws Exception;

	// 전체 조회
	List<Board> readBoard(int videoNo) throws Exception;

	// 하나 조회
	Board selectBoardByNo(int no) throws Exception;

	// 조회수 증가
	void updateViewCnt(int no) throws Exception;

	List<Board> searchByTitle(String title, int videoNo) throws Exception;
}