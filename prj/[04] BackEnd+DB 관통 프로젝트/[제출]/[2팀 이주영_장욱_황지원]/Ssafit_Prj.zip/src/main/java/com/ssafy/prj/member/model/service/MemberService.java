package com.ssafy.prj.member.model.service;

import java.sql.SQLException;

import com.ssafy.prj.member.model.dto.Member;

public interface MemberService {
	void join(Member member) throws Exception;
	
	Member login(Member member) throws Exception;
	
	
}
