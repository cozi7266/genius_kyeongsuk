package com.ssafy.prj.likelist.model.service;

import java.util.ArrayList;
import java.util.List;

import com.ssafy.prj.likelist.model.repository.LikelistRepository;
import com.ssafy.prj.likelist.model.repository.LikelistRepositoryImpl;
import com.ssafy.prj.member.model.dto.Member;
import com.ssafy.prj.video.model.dto.Video;

public class LikelistServiceImpl implements LikelistService {
	private static LikelistRepository likeDao;
	private LikelistServiceImpl() {
		likeDao = LikelistRepositoryImpl.getInstance();
	}
	private static LikelistService instance = new LikelistServiceImpl();
	public static LikelistService getInstance() {
		return instance;
	}
	
	// 찜목록 추가
	@Override
	public boolean addLikelist(Video video, Member member) throws Exception {
		if (!likeDao.isInLikelist(video, member)) {
			likeDao.insertLikelist(video, member);
			return true;
		}
		return false;
	}
	
	// 찜 목록에서 한 개 삭제
	@Override
	public void deleteLikeVideo(Video video, Member member) throws Exception {
		likeDao.deleteLikelistByVideoNo(video, member);
	}
	
	// 찜 목록 전체 삭제
	@Override
	public void deleteAll(Member member) throws Exception {
		likeDao.deleteLikelist(member);
	}
	
	// 찜 목록 리스트
	@Override
	public List<String> Likelist(Member member) throws Exception {
		List<String> list = new ArrayList<>();
		
		list = likeDao.readLikelist(member);
		
		return list;
	}
}
