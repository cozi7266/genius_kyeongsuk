package com.ssafy.prj.board.model.service;

import java.util.List;

import com.ssafy.prj.board.model.dto.Board;

public interface BoardService {

	// 삭제
	void delete(int no) throws Exception;

	// 수정
	void update(Board board) throws Exception;

	// 상세 조회
	Board detail(int no) throws Exception;

	// 목록
	List<Board> list(int videoNo) throws Exception;

	// 등록
	void write(Board board) throws Exception;

	List<Board> search(String title, int videoNo) throws Exception;
}