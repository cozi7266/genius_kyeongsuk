package com.ssafy.prj.board.model.service;

import java.util.List;

import com.ssafy.prj.board.model.dto.Board;
import com.ssafy.prj.board.model.repository.BoardRepository;
import com.ssafy.prj.board.model.repository.BoardRepositoryImpl;
import com.ssafy.prj.video.model.repository.VideoRepository;

public class BoardServiceImpl implements BoardService {
	
	private BoardRepository boardRepository;
	
	private BoardServiceImpl () {
		boardRepository = BoardRepositoryImpl.getInstance();
	}
	private static BoardService instance = new BoardServiceImpl();
	public static BoardService getInstance() {
		return instance;
	}
	
	
	
	
	// 삭제
	@Override
	public void delete(int no) throws Exception {
		boardRepository.deleteBoard(no);
	}
	
	// 수정
	@Override
	public void update(Board board) throws Exception {
		boardRepository.updateBoard(board);
	}

	// 상세 조회
	@Override
	public Board detail(int no) throws Exception {
		boardRepository.updateViewCnt(no);
		Board board = boardRepository.selectBoardByNo(no);
		return board;
	}
	
	// 목록
	@Override
	public List<Board> list(int videoNo) throws Exception {
		List<Board> list = boardRepository.readBoard(videoNo);
		
		return list;
	}

	// 등록
	@Override
	public void write(Board board) throws Exception {
		boardRepository.insertBoard(board);
	}


	// 제목으로 검색
	@Override
	public List<Board> search(String title, int videoNo) throws Exception {
		List<Board> list = boardRepository.searchByTitle(title, videoNo);
		return list;
	}
}
