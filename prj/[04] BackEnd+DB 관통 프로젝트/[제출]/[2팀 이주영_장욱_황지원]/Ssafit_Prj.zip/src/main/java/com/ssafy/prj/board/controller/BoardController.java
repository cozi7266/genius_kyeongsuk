package com.ssafy.prj.board.controller;

import java.io.IOException;
import java.util.List;

import com.ssafy.prj.board.model.dto.Board;
import com.ssafy.prj.board.model.repository.BoardRepository;
import com.ssafy.prj.board.model.repository.BoardRepositoryImpl;
import com.ssafy.prj.board.model.service.BoardService;
import com.ssafy.prj.board.model.service.BoardServiceImpl;
import com.ssafy.prj.video.model.dto.Video;
import com.ssafy.prj.video.service.VideoService;
import com.ssafy.prj.video.service.VideoServiceImpl;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/board")
public class BoardController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private BoardService boardService;
	private VideoService videoService;
	public BoardController() {
		boardService = BoardServiceImpl.getInstance();
		videoService = VideoServiceImpl.getInstance();
	}
	
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			String action = req.getParameter("action");
			
			if ("writeForm".equals(action)) {
				writeForm(req, resp);
			} else if ("write".equals(action)) {
				write(req, resp);
			} else if ("list".equals(action)) {
				list(req, resp);
			} else if ("detail".equals(action)) {
				detail(req, resp);
			} else if ("delete".equals(action)) {
				delete(req, resp);
			} else if ("updateForm".equals(action)) {
				updateForm(req, resp);
			} else if ("update".equals(action)) {
				update(req, resp);
			} else if ("search".equals(action)) {
				search(req, resp);
			}
		} catch (Exception e) {
			e.printStackTrace();
			// 톰켓한테 예외를 만들어서 던진다.
			throw new ServletException(e);
		}
	}

	private void search(HttpServletRequest req, HttpServletResponse resp) throws Exception {
		int videoNo = Integer.parseInt(req.getParameter("videoNo"));
		String title = req.getParameter("title");
		
		List<Board> list = boardService.search(title, videoNo);
		
		// 화면에 보여줄 데이터 준비
		Video video = videoService.detailVideo(videoNo);
		
		// 공유영역
		req.setAttribute("searchList", list);
		req.setAttribute("videoNo", videoNo);
		req.setAttribute("video", video);
		
		// 목록 페이지로 이동
		RequestDispatcher rd = req.getRequestDispatcher("/WEB-INF/board/list.jsp");
		rd.forward(req, resp);
		
	}

	private void update(HttpServletRequest req, HttpServletResponse resp) throws ServletException, Exception {
		int videoNo = Integer.parseInt(req.getParameter("videoNo"));
		int no = Integer.parseInt(req.getParameter("no"));
		
		String title = req.getParameter("title");
		String writer = req.getParameter("writer");
		String content = req.getParameter("content");
		
		Board board = new Board();
		board.setReviewNo(no);
		board.setWriter(writer);
		board.setTitle(title);
		board.setContent(content);
		
		boardService.update(board);
		
		resp.sendRedirect(req.getContextPath() + "/board?action=list&videoNo=" + videoNo);
	}

	private void updateForm(HttpServletRequest req, HttpServletResponse resp) throws Exception {
		int no = Integer.parseInt(req.getParameter("no"));
		Board board = boardService.detail(no);
		
		req.setAttribute("board", board);
		
		RequestDispatcher rd = req.getRequestDispatcher("WEB-INF/board/update.jsp");
		rd.forward(req, resp);
	}

	private void delete(HttpServletRequest req, HttpServletResponse resp) throws Exception {
		int videoNo = Integer.parseInt(req.getParameter("videoNo"));
		int no = Integer.parseInt(req.getParameter("no"));
		boardService.delete(no);
		resp.sendRedirect(req.getContextPath() + "/board?action=list&videoNo=" + videoNo);
	}

	private void detail(HttpServletRequest req, HttpServletResponse resp) throws Exception {
		// 조회할 게시글 번호 가져오기
		int no = Integer.parseInt(req.getParameter("no"));
		// 조회수 증가
		Board board = boardService.detail(no);
		req.setAttribute("board", board);
		RequestDispatcher rd = req.getRequestDispatcher("WEB-INF/board/detail.jsp");
		rd.forward(req, resp);
	}

	private void list(HttpServletRequest req, HttpServletResponse resp) throws Exception {
		int videoNo = Integer.parseInt(req.getParameter("videoNo"));
		// 화면에 보여줄 데이터 준비
		List<Board> list = boardService.list(videoNo);
		Video video = videoService.detailVideo(videoNo);
		
		// 공유영역
		req.setAttribute("list", list);
		req.setAttribute("videoNo", videoNo);
		req.setAttribute("video", video);
		
		// 목록 페이지로 이동
		RequestDispatcher rd = req.getRequestDispatcher("/WEB-INF/board/list.jsp");
		rd.forward(req, resp);
	}

	private void write(HttpServletRequest req, HttpServletResponse resp) throws Exception {
		int videoNo = Integer.parseInt(req.getParameter("videoNo"));
		
		String title = req.getParameter("title");
		String writer = req.getParameter("writer");
		String content = req.getParameter("content");
		
		Board board = new Board();
		board.setVideoNo(videoNo);
		board.setTitle(title);
		board.setWriter(writer);
		board.setContent(content);
		boardService.write(board);
		
		resp.sendRedirect(req.getContextPath() + "/board?action=list&videoNo="+videoNo);
	}

	private void writeForm(HttpServletRequest req, HttpServletResponse resp) throws Exception {
		int videoNo = Integer.parseInt(req.getParameter("videoNo"));
		req.setAttribute("videoNo", videoNo);
		
		// 리뷰 등록 페이지로 이동
		RequestDispatcher rd = req.getRequestDispatcher("/WEB-INF/board/write.jsp");
		rd.forward(req, resp);
	}

}
