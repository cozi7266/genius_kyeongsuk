package com.ssafy.prj.likelist.controller;

import java.io.IOException;

import com.ssafy.prj.likelist.model.service.LikelistService;
import com.ssafy.prj.likelist.model.service.LikelistServiceImpl;
import com.ssafy.prj.member.model.dto.Member;
import com.ssafy.prj.video.model.dto.Video;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/like")
public class LikelistController extends HttpServlet {
	
	private LikelistService likelistService;
	public LikelistController() {
		likelistService = LikelistServiceImpl.getInstance();
	}
	
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			String action = req.getParameter("action");
			
			if ("addLike".equals(action)) {
				addLike(req, resp);
			} else if ("deleteLike".equals(action)) {
				deleteLike(req, resp);
			} else if ("clearLikelist".equals(action)) {
				clearLikelist(req, resp);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new ServletException();
		}
	}

	private void clearLikelist(HttpServletRequest req, HttpServletResponse resp) throws Exception {
		HttpSession session = req.getSession();
		Member member = (Member) session.getAttribute("memberInfo");
		
		likelistService.deleteAll(member);
		
		resp.sendRedirect(req.getContextPath() + "/member?action=mypage");
	}

	private void deleteLike(HttpServletRequest req, HttpServletResponse resp) throws Exception {
		HttpSession session = req.getSession();
		Member member = (Member) session.getAttribute("memberInfo");
		
		Video video = new Video();
		video.setVideoName(req.getParameter("videoName"));
		
		likelistService.deleteLikeVideo(video, member);
		
		resp.sendRedirect(req.getContextPath() + "/member?action=mypage");
	}

	private void addLike(HttpServletRequest req, HttpServletResponse resp) throws Exception {
		HttpSession session = req.getSession();
		Member member = (Member) session.getAttribute("memberInfo");
		
		Video video = new Video();
		video.setVideoName(req.getParameter("videoName"));
		
		boolean isAdd = likelistService.addLikelist(video, member);
		
		resp.sendRedirect(req.getContextPath() + "/main?isAdd=" + isAdd);
	}
}
