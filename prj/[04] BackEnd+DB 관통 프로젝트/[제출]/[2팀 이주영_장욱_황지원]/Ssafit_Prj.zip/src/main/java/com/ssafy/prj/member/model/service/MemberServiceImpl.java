package com.ssafy.prj.member.model.service;

import java.sql.SQLException;

import com.ssafy.prj.member.model.dto.Member;
import com.ssafy.prj.member.model.repository.MemberRepository;
import com.ssafy.prj.member.model.repository.MemberRepositoryImpl;

public class MemberServiceImpl implements MemberService{

	public MemberRepository memberRepository;
	
	// 싱글턴
	private static MemberService memberService = new MemberServiceImpl();
	private MemberServiceImpl() {
		memberRepository = MemberRepositoryImpl.getInstance();
	}
	public static MemberService getInstance() {
		return memberService;
	}
	
	@Override
	public void join(Member member) throws Exception {
		memberRepository.insertMember(member);
	}
	
	@Override 
	public Member login(Member member) throws Exception {
		Member m = memberRepository.selectMember(member);
		return m;
	}
	
}
