package com.ssafy.prj.video.service;

import java.util.List;

import com.ssafy.prj.video.model.dto.Video;

public interface VideoService {

	// 비디오 상세 조회
	Video detailVideo(int no) throws Exception;

	// 핫 비디오 6개
	List<Video> hotVideo() throws Exception;

	// 전체 비디오 조회
	List<Video> videoList() throws Exception;

}