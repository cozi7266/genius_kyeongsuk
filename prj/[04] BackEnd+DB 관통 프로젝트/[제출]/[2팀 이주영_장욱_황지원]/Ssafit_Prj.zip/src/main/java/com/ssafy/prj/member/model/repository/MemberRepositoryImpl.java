package com.ssafy.prj.member.model.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.ssafy.prj.member.model.dto.Member;
import com.ssafy.prj.util.DBUtil;

public class MemberRepositoryImpl implements MemberRepository {
	private DBUtil dbUtil;
	private static MemberRepository instance = new MemberRepositoryImpl();
	private MemberRepositoryImpl() {
		dbUtil = DBUtil.getInstance();
	}
	public static MemberRepository getInstance() {
		return instance;
	}
	
	@Override
	public void insertMember(Member member) throws Exception {
		String sql = "INSERT INTO member(id, name, email, password) VALUES(?, ?, ?, ?);";
		
		try(
				Connection con = dbUtil.getConnection();
				PreparedStatement pstmt = con.prepareStatement(sql);
		   ) 
		{
			pstmt.setString(1, member.getId());
			pstmt.setString(2, member.getName());
			pstmt.setString(3, member.getEmail());
			pstmt.setString(4, member.getPassword());
			
			pstmt.executeUpdate();
		}
	}
	
	@Override
	public Member selectMember(Member member) throws Exception {
		String sql = "SELECT id, name, email, password FROM member WHERE id=?";
		
		try(
				Connection con = dbUtil.getConnection();
				PreparedStatement pstmt = con.prepareStatement(sql);
		   ) 
		{
			pstmt.setString(1, member.getId());
			
			ResultSet rs = pstmt.executeQuery();
			
			while(rs.next()) {
				String id = rs.getString("id");
				String name = rs.getString("name");
				String email = rs.getString("email");
				String password = rs.getString("password");
				
				if(member.getId().equals(id) && member.getPassword().equals(password)) {
					Member m = new Member();
					m.setId(id);
					m.setName(name);
					m.setEmail(email);
					m.setPassword(password);
					return m;
				}
			}
		}
		return null;
	}
}