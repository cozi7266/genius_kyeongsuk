package com.ssafy.prj.member.model.repository;

import java.sql.SQLException;

import com.ssafy.prj.member.model.dto.Member;

public interface MemberRepository {

	void insertMember(Member member) throws Exception;

	Member selectMember(Member tmp) throws Exception;

}
