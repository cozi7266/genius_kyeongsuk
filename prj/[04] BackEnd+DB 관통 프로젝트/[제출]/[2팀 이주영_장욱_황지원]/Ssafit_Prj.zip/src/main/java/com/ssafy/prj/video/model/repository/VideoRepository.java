package com.ssafy.prj.video.model.repository;

import java.util.List;

import com.ssafy.prj.video.model.dto.Video;

public interface VideoRepository {

	// 전체 비디오 조회
	List<Video> selectVideo() throws Exception;

	// 핫 비디오 6개
	List<Video> selectHotVideo() throws Exception;

	// 비디오 조회수 증가
	void updateVideoViewCnt(int no) throws Exception;

	// 비디오 하나 조회
	Video selectVideoByNo(int no) throws Exception;

}