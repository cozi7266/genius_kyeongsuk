package com.ssafy.prj.follow.model.repository;

import java.util.List;

import com.ssafy.prj.member.model.dto.Member;

public interface FollowRepository {

	// 팔로우 목록에 추가
	void insertFollow(Member m1, Member m2) throws Exception;

	// 팔로우 목록에서 하나 삭제
	void deleteFollow(Member m1, Member m2) throws Exception;

	// 팔로우 목록에서 전체 삭제
	void deleteAll(Member member) throws Exception;

	// 팔로우 목록에 이미 있는 사람인지 검사
	boolean isFollowed(Member m1, Member m2) throws Exception;

	// 팔로우 목록 조회
	List<String> selectFollow(Member member) throws Exception;

}