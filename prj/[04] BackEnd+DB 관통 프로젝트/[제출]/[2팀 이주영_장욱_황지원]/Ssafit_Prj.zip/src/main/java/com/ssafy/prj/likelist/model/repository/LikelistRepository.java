package com.ssafy.prj.likelist.model.repository;

import java.util.List;

import com.ssafy.prj.member.model.dto.Member;
import com.ssafy.prj.video.model.dto.Video;

public interface LikelistRepository {

	// 찜 목록에 추가
	void insertLikelist(Video video, Member member) throws Exception;

	// 찜 목록에서 하나 삭제
	void deleteLikelistByVideoNo(Video video, Member member) throws Exception;

	// 찜 목록 전체 삭제
	void deleteLikelist(Member member) throws Exception;

	// 찜 목록에 있는 항목인지 검사 => 생각 좀 더 해봐봐
	boolean isInLikelist(Video video, Member member) throws Exception;

	// 찜목록 조회
	List<String> readLikelist(Member member) throws Exception;

}