package com.ssafy.prj.likelist.model.service;

import java.util.List;

import com.ssafy.prj.member.model.dto.Member;
import com.ssafy.prj.video.model.dto.Video;

public interface LikelistService {

	// 찜목록 추가
	boolean addLikelist(Video video, Member member) throws Exception;

	// 찜 목록에서 한 개 삭제
	void deleteLikeVideo(Video video, Member member) throws Exception;

	// 찜 목록 전체 삭제
	void deleteAll(Member member) throws Exception;

	// 찜 목록 리스트
	List<String> Likelist(Member member) throws Exception;

}