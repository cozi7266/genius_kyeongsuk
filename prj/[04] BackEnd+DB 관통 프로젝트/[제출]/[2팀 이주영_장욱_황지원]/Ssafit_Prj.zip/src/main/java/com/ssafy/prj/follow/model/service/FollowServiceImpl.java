package com.ssafy.prj.follow.model.service;

import java.util.ArrayList;
import java.util.List;

import com.ssafy.prj.follow.model.repository.FollowRepository;
import com.ssafy.prj.follow.model.repository.FollowRepositoryImpl;
import com.ssafy.prj.member.model.dto.Member;

public class FollowServiceImpl implements FollowService {
	private static FollowRepository followRepo;
	private FollowServiceImpl() {
		followRepo = FollowRepositoryImpl.getInstance();
	}
	private static FollowService instance = new FollowServiceImpl();
	public static FollowService getInstance() {
		return instance;
	}
	
	// 팔로우 목록에 추가
	@Override
	public boolean addFollow(Member m1, Member m2) throws Exception {
		if (!followRepo.isFollowed(m1, m2)) {
			followRepo.insertFollow(m1, m2);
			return true;
		}
		return false;
	}
	
	// 팔로우 목록에서 제거
	@Override
	public void stopFollow(Member m1, Member m2) throws Exception {
		followRepo.deleteFollow(m1, m2);
	}
	
	// 팔로우 목록 전체 제거
	@Override
	public void stopFollowAll(Member member) throws Exception {
		followRepo.deleteAll(member);
	}
	
	// 팔로우 목록 리스트
	@Override
	public List<String> FollowingList(Member member) throws Exception {
		List<String> list = new ArrayList<>();
		
		list = followRepo.selectFollow(member);
		
		return list;
	}
}
