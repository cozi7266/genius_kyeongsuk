package com.ssafy.prj.likelist.model.dto;

public class Likelist {
	int like_no;
	String id;
	String like_video;
	public Likelist() {}
	public Likelist(int like_no, String id, String like_video) {
		this.like_no = like_no;
		this.id = id;
		this.like_video = like_video;
	}
	public int getLike_no() {
		return like_no;
	}
	public void setLike_no(int like_no) {
		this.like_no = like_no;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getLike_video() {
		return like_video;
	}
	public void setLike_video(String like_video) {
		this.like_video = like_video;
	}
	@Override
	public String toString() {
		return "Likelist [like_no=" + like_no + ", id=" + id + ", like_video=" + like_video + "]";
	}
}
