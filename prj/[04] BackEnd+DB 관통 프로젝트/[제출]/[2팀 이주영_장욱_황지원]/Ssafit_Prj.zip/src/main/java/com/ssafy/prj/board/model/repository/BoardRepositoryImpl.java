package com.ssafy.prj.board.model.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.ssafy.prj.board.model.dto.Board;
import com.ssafy.prj.util.DBUtil;

public class BoardRepositoryImpl implements BoardRepository {
	
	private DBUtil dbUtil;
	
	private BoardRepositoryImpl() {
		dbUtil = DBUtil.getInstance();
	}
	private static BoardRepository instance = new BoardRepositoryImpl();
	public static BoardRepository getInstance() {
		return instance;
	}
	
	// 등록
	@Override
	public void insertBoard(Board board) throws Exception {
		String sql = "INSERT INTO review(title, writer, content, video_no) VALUES(?, ?, ?, ?)";
		
		try(
				Connection con = dbUtil.getConnection();
				PreparedStatement pstmt = con.prepareStatement(sql);
		   ) 
		{
			pstmt.setString(1, board.getTitle());
			pstmt.setString(2, board.getWriter());
			pstmt.setString(3, board.getContent());
			pstmt.setInt(4, board.getVideoNo());
			
			pstmt.executeUpdate();
		}
	}
	
	// 수정
	@Override
	public void updateBoard(Board board) throws Exception {
		String sql = "UPDATE review SET title = ? , content = ? WHERE review_no = ?";
		
		try(
				Connection con = dbUtil.getConnection();
				PreparedStatement pstmt = con.prepareStatement(sql);
		   ) 
		{
			pstmt.setString(1, board.getTitle());
			pstmt.setString(2, board.getContent());
			pstmt.setInt(3, board.getReviewNo());
			
			pstmt.executeUpdate();
		}
	}
	
	// 삭제
	@Override
	public void deleteBoard(int no) throws Exception {
		String sql = "DELETE FROM review WHERE review_no = ?";
		
		try(
				Connection con = dbUtil.getConnection();
				PreparedStatement pstmt = con.prepareStatement(sql);
		   ) 
		{
			pstmt.setInt(1, no);
			
			pstmt.executeUpdate();
		}
	}
	
	// 전체 조회
	@Override
	public List<Board> readBoard(int videoNo) throws Exception {
		List<Board> list = new ArrayList<>();
		
		String sql = "SELECT * FROM review WHERE video_no = ?";
		
		try(
				Connection con = dbUtil.getConnection();
				PreparedStatement pstmt = con.prepareStatement(sql);
		   ) 
		{
			pstmt.setInt(1, videoNo);
			
			ResultSet rs = pstmt.executeQuery();
			
			while (rs.next()) {
				Board tmp = new Board();
				
				tmp.setReviewNo(Integer.parseInt(rs.getString("review_no")));
				tmp.setTitle(rs.getString("title"));
				tmp.setWriter(rs.getString("writer"));
				tmp.setContent(rs.getString("content"));
				tmp.setViewCnt(Integer.parseInt(rs.getString("view_cnt")));
				tmp.setVideoNo(Integer.parseInt(rs.getString("video_no")));
				tmp.setRegDate(rs.getString("reg_date"));
				
				list.add(tmp);
			}
		}
		return list;
	}
	
	// 하나 조회
	@Override
	public Board selectBoardByNo(int no) throws Exception {
		String sql = "SELECT * FROM review WHERE review_no = ?";
		
		try(
				Connection con = dbUtil.getConnection();
				PreparedStatement pstmt = con.prepareStatement(sql);
		   ) 
		{
			pstmt.setInt(1, no);
			
			ResultSet rs = pstmt.executeQuery();
			
			Board tmp = new Board();
			
			while (rs.next()) {
				tmp.setReviewNo(Integer.parseInt(rs.getString("review_no")));
				tmp.setTitle(rs.getString("title"));
				tmp.setWriter(rs.getString("writer"));
				tmp.setContent(rs.getString("content"));
				tmp.setViewCnt(Integer.parseInt(rs.getString("view_cnt")));
				tmp.setVideoNo(Integer.parseInt(rs.getString("video_no")));
				tmp.setRegDate(rs.getString("reg_date"));
				return tmp;
			}
		}
		return null;
	}
	
	// 리뷰 조회수 증가
	@Override
	public void updateViewCnt(int no) throws Exception {
		String sql = "UPDATE review SET view_cnt = view_cnt + 1 WHERE review_no = ?";
		
		try(
				Connection con = dbUtil.getConnection();
				PreparedStatement pstmt = con.prepareStatement(sql);
		   ) 
		{
			pstmt.setInt(1, no);
			
			pstmt.executeUpdate();
		}
	}

	@Override
	public List<Board> searchByTitle(String title, int videoNo) throws Exception {
		List<Board> list = new ArrayList<>();
		
		String sql = "SELECT * FROM review WHERE title LIKE ? AND video_no = ?";
		
		try(
				Connection con = dbUtil.getConnection();
				PreparedStatement pstmt = con.prepareStatement(sql);
		   ) 
		{
			pstmt.setString(1, "%"+title+"%");
			pstmt.setInt(2, videoNo);
			
			ResultSet rs = pstmt.executeQuery();
			
			while (rs.next()) {
				Board tmp = new Board();

				tmp.setReviewNo(Integer.parseInt(rs.getString("review_no")));
				tmp.setTitle(rs.getString("title"));
				tmp.setWriter(rs.getString("writer"));
				tmp.setContent(rs.getString("content"));
				tmp.setViewCnt(Integer.parseInt(rs.getString("view_cnt")));
				tmp.setVideoNo(Integer.parseInt(rs.getString("video_no")));
				tmp.setRegDate(rs.getString("reg_date"));
				
				list.add(tmp);
			}
		}
		return list;
	}
}
