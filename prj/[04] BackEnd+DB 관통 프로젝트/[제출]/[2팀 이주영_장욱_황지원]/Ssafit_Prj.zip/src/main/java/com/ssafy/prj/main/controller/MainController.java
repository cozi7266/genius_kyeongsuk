package com.ssafy.prj.main.controller;

import java.io.IOException;
import java.util.List;

import com.ssafy.prj.video.model.dto.Video;
import com.ssafy.prj.video.service.VideoService;
import com.ssafy.prj.video.service.VideoServiceImpl;

import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/main")
public class MainController extends HttpServlet{
	private static final long serialVersionUID = 1L;
	
	private static VideoService videoService = VideoServiceImpl.getInstance();

	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// 어플리케이션 영역에 video 정보 로드 
		try {
			List<Video> videoList = videoService.videoList();
			List<Video> hotVideoList = videoService.hotVideo();
			
			ServletContext context = getServletContext();
			context.setAttribute("videoList", videoList);
			context.setAttribute("hotVideoList", hotVideoList);
			
			// 페이지 이동
			req.getRequestDispatcher("main.jsp").forward(req, resp);
		} catch (Exception e) {
			e.printStackTrace();
			throw new ServletException();
		} 
	}
}
