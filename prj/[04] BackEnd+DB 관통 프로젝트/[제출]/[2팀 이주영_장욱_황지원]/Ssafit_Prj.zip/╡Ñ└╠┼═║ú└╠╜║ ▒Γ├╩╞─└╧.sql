DROP DATABASE IF EXISTS ssafit_prj;

CREATE DATABASE IF NOT EXISTS ssafit_prj;

USE ssafit_prj;

CREATE TABLE IF NOT EXISTS member (
    id VARCHAR(40),
    name VARCHAR(30) NOT NULL,
    email VARCHAR(80) UNIQUE,
    password VARCHAR(80) NOT NULL,
    PRIMARY KEY(id)
);

CREATE TABLE IF NOT EXISTS video (
	video_no INT AUTO_INCREMENT,
    video_name VARCHAR(200) UNIQUE NOT NULL, 
    url VARCHAR(1000) NOT NULL,
    image VARCHAR(1000),
    part VARCHAR(40) NOT NULL,
    channel_name VARCHAR(80) NOT NULL,
    view_cnt INT DEFAULT 0,
    PRIMARY KEY(video_no)
);

CREATE TABLE IF NOT EXISTS review (
	review_no INT AUTO_INCREMENT,
    video_no INT,
    title VARCHAR(150) NOT NULL,
    writer VARCHAR(40) NOT NULL,
    content VARCHAR(10000) NOT NULL,
    view_cnt INT DEFAULT 0,
    reg_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (writer) REFERENCES member(id) ON DELETE CASCADE,
    FOREIGN KEY (video_no) REFERENCES video(video_no) ON DELETE CASCADE,
    PRIMARY KEY(review_no)
);

CREATE TABLE IF NOT EXISTS follow (
	followed_id VARCHAR(40),
    following_id VARCHAR(40),
    FOREIGN KEY (following_id) REFERENCES member(id) ON DELETE CASCADE,
    FOREIGN KEY (followed_id) REFERENCES member(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS like_list (
	like_no INT AUTO_INCREMENT,
    id VARCHAR(40),
    like_video VARCHAR(200),
    PRIMARY KEY(like_no),
    FOREIGN KEY (id) REFERENCES member(id) ON DELETE CASCADE,
    FOREIGN KEY (like_video) REFERENCES video(video_name) ON DELETE CASCADE
);

INSERT INTO video(video_name, url, image, part, channel_name) VALUES
	("Shim EuDdeum 10 Minute Morning Stretch Everydayㅣ2023 Renewal", '<iframe width="560" height="315" src="https://www.youtube.com/embed/50WCSpZtdmA?si=UQPcuJxny6PYTaBX" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>', "https://img.youtube.com/vi/50WCSpZtdmA/sddefault.jpg", "전신", "힘으뜸"), 
    ("하루 두 번🧘🏻‍♀️반드시 해야하는 20분 전신순환 스트레칭 Ep.08 - 피로회복, 디톡스, 심신안정, 혈액순환, 라인정리 효과 (Whole body stretch)", '<iframe width="560" height="315" src="https://www.youtube.com/embed/Kk7TQGqQ3nA?si=zF_CwvfVXxn3_LOR" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>', "https://img.youtube.com/vi/Kk7TQGqQ3nA/sddefault.jpg", "전신", "빵느"), 
    ("4 Minute OFFICE STRETCHING(full body)", '<iframe width="560" height="315" src="https://www.youtube.com/embed/MTU4iCDntjs?si=AoiAXuTwaKAqpOjI" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>', "https://img.youtube.com/vi/MTU4iCDntjs/sddefault.jpg", "전신", "Allblanc TV"), 
    ("뭉친 어깨, 뻣뻣한 골반 풀어주는 요가 | 앉아서 하는 요가 스트레칭 | 어깨 근육 풀기, 골반풀기", '<iframe width="560" height="315" src="https://www.youtube.com/embed/D3yExRi7EME?si=MzLQ40c5QWCcknul" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>', "https://img.youtube.com/vi/FMOISIlhLEY/sddefault.jpg", "상체", "Mindful Yoga with Eileen"),
	("15 MIN Fat Burning Cardio - 서서하는 유산소 - 다이어트 운동", '<iframe width="560" height="315" src="https://www.youtube.com/embed/02K-k6daPb4?si=yHlzdGajaTg_DXiy" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>', "https://img.youtube.com/vi/02K-k6daPb4/sddefault.jpg", "전신", "빅씨스 Bigsis"), 
    ("전신 다이어트 최고의 운동 [칼소폭 찐 핵핵매운맛]", '<iframe width="560" height="315" src="https://www.youtube.com/embed/gMaB-fG4u4g?si=jfGKevW5cbPiKwUN" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>', "https://img.youtube.com/vi/gMaB-fG4u4g/sddefault.jpg", "전신", "ThankyouBUBU"), 
    ("하루 15분! 전신 칼로리 불태우는 다이어트 운동", '<iframe width="560" height="315" src="https://www.youtube.com/embed/swRNeYw1JkY?si=_-8j2VsppivGJ997" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>', "https://img.youtube.com/vi/swRNeYw1JkY/sddefault.jpg", "전신", "ThankyouBUBU"), 
    ("상체 다이어트 최고의 운동 BEST [팔뚝살/겨드랑이살/등살/가슴어깨라인]", '<iframe width="560" height="315" src="https://www.youtube.com/embed/54tTYO-vU2E?si=0VzvdY_ZoK1o3oB-" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>', "https://img.youtube.com/vi/54tTYO-vU2E/sddefault.jpg", "상체", "ThankyouBUBU"),
	("상체비만 다이어트 최고의 운동 [상체 핵매운맛]", '<iframe width="560" height="315" src="https://www.youtube.com/embed/QqqZH3j_vH0?si=OGcI_D7JsuZPzp3-" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>', "https://img.youtube.com/vi/QqqZH3j_vH0/sddefault.jpg", "상체", "ThankyouBUBU"), 
	("하체운동이 중요한 이유? 이것만 보고 따라하자 ! [하체운동 교과서]", '<iframe width="560" height="315" src="https://www.youtube.com/embed/tzN6ypk6Sps?si=3YFOSJWYBfjMwd6Y" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>', "https://img.youtube.com/vi/tzN6ypk6Sps/sddefault.jpg", "하체", "김강민"), 
    ("저는 하체 식주의자 입니다", '<iframe width="560" height="315" src="https://www.youtube.com/embed/u5OgcZdNbMo?si=CfO5qu6CXmV61LmR" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>', "https://img.youtube.com/vi/u5OgcZdNbMo/sddefault.jpg", "하체", "GYM종국"), 
    ("11자복근 복부 최고의 운동 [복근 핵매운맛]", '<iframe width="560" height="315" src="https://www.youtube.com/embed/PjGcOP-TQPE?si=NxqB6ZinwZaI_YxU" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>', "https://img.youtube.com/vi/PjGcOP-TQPE/sddefault.jpg", "복부", "ThankyouBUBU"), 
    ("(Sub)누워서하는 5분 복부운동!! 효과보장! (매일 2주만 해보세요!)", '<iframe width="560" height="315" src="https://www.youtube.com/embed/7TLk7pscICk?si=Qs1twruBe-RMRy1R" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>', "https://img.youtube.com/vi/7TLk7pscICk/sddefault.jpg", "복부", "SomiFit");

INSERT INTO member(id, name, email, password) VALUES
	('ssafy', 'SSAFY', 'ssafy@ssafy.com', '1111'),
	('fpower_yoyng', '이주영', 'fpower_yoyng@ssafy.com', '1111'),
	('janguk95', '장욱', 'janguk95@ssafy.com', '1111'),
	('hjw9265', '황지원', 'hjw9265@ssafy.com', '1111');