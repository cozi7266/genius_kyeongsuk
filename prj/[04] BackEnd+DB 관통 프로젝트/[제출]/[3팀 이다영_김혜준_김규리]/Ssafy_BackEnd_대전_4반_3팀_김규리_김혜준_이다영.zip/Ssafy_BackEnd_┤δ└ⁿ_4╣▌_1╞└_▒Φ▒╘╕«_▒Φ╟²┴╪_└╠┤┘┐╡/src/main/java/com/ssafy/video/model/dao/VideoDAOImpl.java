package com.ssafy.video.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ssafy.util.DBUtil;
import com.ssafy.video.model.dto.Video;

public class VideoDAOImpl implements VideoDAO {

	private static VideoDAO instance = new VideoDAOImpl();

	private VideoDAOImpl() {
	};

	public static VideoDAO getIntstance() {
		return instance;
	}

	public static void main(String[] args) throws SQLException {
		DBUtil dbUtil = DBUtil.getInstance();
		Connection con = dbUtil.getConnection();
		System.out.println(con);
	}

	@Override
	public List<Video> selectVideoHard() throws SQLException {

		List<Video> hardList = new ArrayList<>();

		DBUtil dbUtil = DBUtil.getInstance();
		// 데이터베이스 연결하기
		Connection con = dbUtil.getConnection();
		// 실행할 SQL 문 작성
		String sql = "select VIDEO_ID, VIDEO_TITLE, VIDEO_LINK, VIDEO_PATH, VIDEO_TARGET, VIDEO_LEVEL, VIDEO_TARGET_PATH from video where video_level = 'hard' order by VIDEO_ID";
		// SQL문을 실행할 객체를 얻어온다.
		PreparedStatement pstmt = con.prepareStatement(sql);
		// SQL문 실행하기 : select(executeQuery), select절 이외(executeUpdate)
		ResultSet rs = pstmt.executeQuery();

		while (rs.next()) {
			int videoId = rs.getInt("VIDEO_ID");
			String videoTitle = rs.getString("VIDEO_TITLE");
			String videoLink = rs.getString("VIDEO_LINK");
			String videoPath = rs.getString("VIDEO_PATH");
			String videoTarget = rs.getString("VIDEO_TARGET");
			String videoLevel = rs.getString("VIDEO_LEVEL");
			String videoTargetPath = rs.getString("VIDEO_TARGET_PATH");

			Video video = new Video();
			video.setVideoId(videoId);
			video.setVideoLink(videoLink);
			video.setVideoPath(videoPath);
			video.setVideoTarget(videoTarget);
			video.setVideoTitle(videoTitle);
			video.setVideoLevel(videoLevel);
			video.setVideoTargetPath(videoTargetPath);

			hardList.add(video);
		}
		return hardList;
	}
	
	@Override
	public List<Video> selectVideoEasy() throws SQLException {

		List<Video> easyList = new ArrayList<>();

		DBUtil dbUtil = DBUtil.getInstance();
		// 데이터베이스 연결하기
		Connection con = dbUtil.getConnection();
		// 실행할 SQL 문 작성
		String sql = "select VIDEO_ID, VIDEO_TITLE, VIDEO_LINK, VIDEO_PATH, VIDEO_TARGET, VIDEO_LEVEL , VIDEO_TARGET_PATH from video where video_level = 'easy' order by VIDEO_ID";
		// SQL문을 실행할 객체를 얻어온다.
		PreparedStatement pstmt = con.prepareStatement(sql);
		// SQL문 실행하기 : select(executeQuery), select절 이외(executeUpdate)
		ResultSet rs = pstmt.executeQuery();

		while (rs.next()) {
			int videoId = rs.getInt("VIDEO_ID");
			String videoTitle = rs.getString("VIDEO_TITLE");
			String videoLink = rs.getString("VIDEO_LINK");
			String videoPath = rs.getString("VIDEO_PATH");
			String videoTarget = rs.getString("VIDEO_TARGET");
			String videoLevel = rs.getString("VIDEO_LEVEL");
			String videoTargetPath = rs.getString("VIDEO_TARGET_PATH");


			Video video = new Video();
			video.setVideoId(videoId);
			video.setVideoLink(videoLink);
			video.setVideoPath(videoPath);
			video.setVideoTarget(videoTarget);
			video.setVideoTitle(videoTitle);
			video.setVideoLevel(videoLevel);
			video.setVideoTargetPath(videoTargetPath);

			easyList.add(video);
		}
		return easyList;
	}
	
	@Override
	public List<Video> selectVideoAll() throws SQLException {

		List<Video> videoList = new ArrayList<>();

		DBUtil dbUtil = DBUtil.getInstance();
		// 데이터베이스 연결하기
		Connection con = dbUtil.getConnection();
		// 실행할 SQL 문 작성
		String sql = "select VIDEO_ID, VIDEO_TITLE, VIDEO_LINK, VIDEO_PATH, VIDEO_TARGET, VIDEO_LEVEL , VIDEO_TARGET_PATH from video order by VIDEO_ID";
		// SQL문을 실행할 객체를 얻어온다.
		PreparedStatement pstmt = con.prepareStatement(sql);
		// SQL문 실행하기 : select(executeQuery), select절 이외(executeUpdate)
		ResultSet rs = pstmt.executeQuery();

		while (rs.next()) {
			int videoId = rs.getInt("VIDEO_ID");
			String videoTitle = rs.getString("VIDEO_TITLE");
			String videoLink = rs.getString("VIDEO_LINK");
			String videoPath = rs.getString("VIDEO_PATH");
			String videoTarget = rs.getString("VIDEO_TARGET");
			String videoLevel = rs.getString("VIDEO_LEVEL");
			String videoTargetPath = rs.getString("VIDEO_TARGET_PATH");


			Video video = new Video();
			video.setVideoId(videoId);
			video.setVideoLink(videoLink);
			video.setVideoPath(videoPath);
			video.setVideoTarget(videoTarget);
			video.setVideoTitle(videoTitle);
			video.setVideoLevel(videoLevel);
			video.setVideoTargetPath(videoTargetPath);

			videoList.add(video);
		}
		return videoList;
	}


	@Override
	public Video selectVideoByNo(int videoId) throws SQLException {

		DBUtil dbUtil = DBUtil.getInstance();
		// 데이터베이스 연결하기
		Connection con = dbUtil.getConnection();
		// 실행할 SQL 문 작성
		String sql = "select VIDEO_ID, VIDEO_TITLE, VIDEO_LINK, VIDEO_PATH, VIDEO_TARGET , VIDEO_LEVEL, VIDEO_TARGET_PATH from video where VIDEO_ID = ?";
		// SQL문을 실행할 객체를 얻어온다.
		PreparedStatement pstmt = con.prepareStatement(sql);

		// 쿼리문 실행하기 전에 ?에 값을 설정
		pstmt.setInt(1, videoId); // 물음표의 위칫값, 값

		// SQL문 실행하기 : select(executeQuery), select절 이외(executeUpdate)
		ResultSet rs = pstmt.executeQuery();

		if (rs.next()) {
			
			String videoTitle = rs.getString("VIDEO_TITLE");
			String videoLink = rs.getString("VIDEO_LINK");
			String videoPath = rs.getString("VIDEO_PATH");
			String videoTarget = rs.getString("VIDEO_TARGET");
			String videoLevel = rs.getString("VIDEO_LEVEL");
			String VideoTargetPath = rs.getString("VIDEO_TARGET_PATH");

			Video video = new Video();
			video.setVideoId(videoId);
			video.setVideoLink(videoLink);
			video.setVideoPath(videoPath);
			video.setVideoTarget(videoTarget);
			video.setVideoTitle(videoTitle);
			video.setVideoLevel(videoLevel);
			video.setVideoTargetPath(VideoTargetPath);

			return video;
		}
		return null;
	}

}
