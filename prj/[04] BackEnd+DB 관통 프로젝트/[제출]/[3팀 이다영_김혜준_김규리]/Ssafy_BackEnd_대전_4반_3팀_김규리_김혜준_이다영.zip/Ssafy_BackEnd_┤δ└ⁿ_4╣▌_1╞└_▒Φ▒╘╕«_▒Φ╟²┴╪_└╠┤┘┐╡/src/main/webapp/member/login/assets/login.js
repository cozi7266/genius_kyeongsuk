

document.addEventListener('DOMContentLoaded', () => {
	
	let loginBtn = document.getElementsByClassName("btn btn-light");

	loginBtn[1].addEventListener('click', () => {
		location.href = `${contextPath}/main`;
	})

	loginBtn[0].addEventListener('click', () => {

		let idInput = document.getElementById("id").value;
		let passwordInput = document.getElementById("password").value;
		let valid = true;


		// 유효성 검사  
		if (idInput === '') {
			alert('아이디를 입력해 주세요.');
			valid = false;
		}

		if (passwordInput === '') {
			alert('비밀번호를 입력해 주세요.');
			valid = false;
		}

		// 유효성 검사 통과 시 폼 제출
		if (valid) {
			document.getElementById("loginForm").submit();  // 폼 제출
		}

	});

	let errorMessage = document.getElementById('errorMessage').innerText;
	if (errorMessage.trim()) {
		alert(errorMessage); // 에러 메시지가 있을 경우 alert로 출력
	}

});

