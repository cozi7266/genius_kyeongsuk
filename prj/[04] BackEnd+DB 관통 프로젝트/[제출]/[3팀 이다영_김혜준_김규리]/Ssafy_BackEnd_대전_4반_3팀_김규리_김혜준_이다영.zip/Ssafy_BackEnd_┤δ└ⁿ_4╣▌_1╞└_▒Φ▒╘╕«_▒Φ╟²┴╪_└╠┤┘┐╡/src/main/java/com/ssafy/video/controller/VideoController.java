package com.ssafy.video.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import com.ssafy.board.model.service.BoardService;
import com.ssafy.board.model.service.BoardServiceImpl;
import com.ssafy.video.model.dto.Video;
import com.ssafy.video.model.service.VideoService;
import com.ssafy.video.model.service.VideoServiceImpl;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/video")
public class VideoController extends HttpServlet {

    private VideoService videoService;

    public VideoController() {
        videoService = VideoServiceImpl.getInstance();
    }
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String action = req.getParameter("action");
		if ("detail".equals(action)) {
			try {
				detail(req, resp);
			} catch (ServletException | IOException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else {
			try {
				list(req, resp);
			} catch (ServletException | IOException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} 
	}

	private void list(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException, SQLException {
		// 화면에 보여줄 데이터를 준비한다.
		List<Video> easyList = videoService.listVideoEasy();
		List<Video> hardList = videoService.listVideoHard();
		List<Video> videoList = videoService.listVideoAll();
		
		  HttpSession session = req.getSession();
		  
		  // req 같이 볼 수 있는 영역에 올리자(공유영역)
		  session.setAttribute("easyList", easyList);
		  session.setAttribute("hardList", hardList);
		  session.setAttribute("videoList", videoList);
		  
		
//		System.out.println("easyList리스트"+easyList);
//		System.out.println("hardList리스트"+hardList);
//		System.out.println("videoList리스트"+videoList);
		


		// 화면 페이지로 이동한다.(list.jsp)
		RequestDispatcher rd = req.getRequestDispatcher("/main.jsp");
		rd.forward(req, resp);
	}

	private void detail(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException, SQLException {
		// 조회할 게시글 번호 가져오기
		int videoId = Integer.parseInt(req.getParameter("videoId"));

		// 보드 반환
		Map<String, Object> result = videoService.getVideoByNo(videoId);
		// 페이지에 넘길거임 -> (로그인 빼고는 거의 req에 담음)
		req.setAttribute("video", result.get("video"));
		req.setAttribute("boards", result.get("boards")); 
		// 포워드 방식으로 가야함 ( 데이터 공유는 포워드만 가능함 )
		RequestDispatcher rd = req.getRequestDispatcher("/video/detail.jsp");
		rd.forward(req, resp);
	}

}
