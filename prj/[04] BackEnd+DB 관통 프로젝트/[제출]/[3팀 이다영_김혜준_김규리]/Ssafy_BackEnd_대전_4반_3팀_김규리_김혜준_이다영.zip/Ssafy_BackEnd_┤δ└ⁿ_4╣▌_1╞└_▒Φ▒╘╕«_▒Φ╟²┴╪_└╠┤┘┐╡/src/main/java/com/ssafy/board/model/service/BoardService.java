package com.ssafy.board.model.service;

import java.util.List;

import com.ssafy.board.model.dto.Board;

public interface BoardService {

	List<Board> listBoard() throws Exception;
    void insertBoard(Board board) throws Exception;
    Board selectBoardByNo(int no) throws Exception;
    void updateBoard(Board board) throws Exception;
    void deleteBoard(int no) throws Exception;
    void updateViewCount(int no) throws Exception;
    List<Board> listBoardByVideoNo(int videoId) throws Exception;
}
