package com.ssafy.board.model.service;

import java.util.List;

import com.ssafy.board.model.dao.BoardDAO;
import com.ssafy.board.model.dao.BoardDAOImpl;
import com.ssafy.board.model.dto.Board;

public class BoardServiceImpl implements BoardService {

	private BoardDAO boardDao;
	
	private static BoardService instance = new BoardServiceImpl();
	private BoardServiceImpl() {
		boardDao = BoardDAOImpl.getIntstance();
	}
	
	public static BoardService getInstance() {
		return instance;
	}

	@Override
	public List<Board> listBoard() throws Exception {
		return boardDao.selectBoard();
	}
	
	@Override
	public List<Board> listBoardByVideoNo(int videoId) throws Exception {
		return boardDao.selectBoardByVideoNo(videoId);
	}

	@Override
	public void insertBoard(Board board) throws Exception {
		boardDao.insertBoard(board);		
	}

	@Override
	public Board selectBoardByNo(int no) throws Exception {
		return boardDao.selectBoardByNo(no);
	}

	@Override
	public void updateBoard(Board board) throws Exception {
		 boardDao.updateBoard(board);		
	}

	@Override
	public void deleteBoard(int no) throws Exception {
		boardDao.deleteByNo(no);		
	}

	@Override
	public void updateViewCount(int no) throws Exception {
		 boardDao.updateViewCnt(no);		
	}

}
