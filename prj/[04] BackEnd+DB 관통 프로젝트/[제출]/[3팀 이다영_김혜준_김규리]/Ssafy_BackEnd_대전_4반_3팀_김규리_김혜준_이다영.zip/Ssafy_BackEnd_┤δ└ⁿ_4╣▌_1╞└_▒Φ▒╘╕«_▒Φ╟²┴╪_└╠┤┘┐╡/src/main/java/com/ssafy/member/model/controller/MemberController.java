package com.ssafy.member.model.controller;

import java.io.IOException;
import java.sql.SQLException;

import com.ssafy.member.model.dto.Member;
import com.ssafy.member.model.service.MemberService;
import com.ssafy.member.model.service.MemberServiceImpl;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/member")
public class MemberController extends HttpServlet {

	private MemberService memberService;

	public MemberController() {
		memberService = MemberServiceImpl.getInstance();
	}

	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String action = req.getParameter("action");

		if ("join".equals(action)) {
			join(req, resp);
		} else if ("joinForm".equals(action)) {
			joinForm(req, resp);
		} else if ("loginForm".equals(action)) {
			loginForm(req, resp);
		} else if ("login".equals(action)) {
			login(req, resp);
		} else if ("logout".equals(action)) {
			logout(req, resp);
		}
	}

	private void logout(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession session = req.getSession();
		session.invalidate(); // 기존 세션 정보를 지우기
		resp.sendRedirect(req.getContextPath() + "/main?message=logoutSuccess");
	}

	private void login(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String id = req.getParameter("id");
		String password = req.getParameter("password");

		Member member = null;
		try {
			member = memberService.loginMember(new Member(id, null, null, password));
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		// null일 경우 -> id or password가 틀린 경우 -> 로그인 실패
		// null이 아니면 로그인 성공

		if (member != null) {
			HttpSession session = req.getSession(); // 세션에 정보 등록하기
			session.setAttribute("memberInfo", member);
			resp.sendRedirect(req.getContextPath() + "/main");
		} else {
			 req.setAttribute("message", "아이디 또는 비밀번호가 잘못되었습니다.");
			 req.getRequestDispatcher("/member/login/login.jsp").forward(req, resp);
		}
		
	}

	private void loginForm(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// 포워드로

		RequestDispatcher rd = req.getRequestDispatcher("/member/login/login.jsp");
		rd.forward(req, resp);
	}

	private void joinForm(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// /member?action=joinForm
		// /member/join.jsp 이동해야 한다
		// 포워드로
		RequestDispatcher rd = req.getRequestDispatcher("/member/join/join.jsp");
		rd.forward(req, resp);
	}

	/**
	 * 문서화 주석 회원가입 처리
	 * 
	 * @param req
	 * @param resp
	 * @throws ServletException
	 * @throws IOException
	 */

	private void join(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	    String id = req.getParameter("id");
	    String name = req.getParameter("name");
	    String email = req.getParameter("email");
	    String password = req.getParameter("password");

	    Member member = new Member(id, name, email, password);
	    try {
	        boolean isJoined = memberService.joinMember(member);
	        if (isJoined) {
	            // 회원가입 성공 시 로그인 페이지로 리다이렉트
	        	System.out.println("성공");
	        	req.getSession().setAttribute("message", "회원가입이 완료되었습니다.");
	            resp.sendRedirect(req.getContextPath() + "/member?action=loginForm");
	        }
	        else if(!isJoined){
	        	System.out.println("실패");
	            // 회원가입 실패 시 경고 메시지 설정 후 회원가입 페이지로 이동
	            req.getSession().setAttribute("message", "이미 사용 중인 아이디입니다. 다른 아이디를 사용해 주세요.");
	            resp.sendRedirect(req.getContextPath() + "/member/join/join.jsp");
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	        req.getSession().setAttribute("message", "회원가입 중 오류가 발생했습니다. 다시 시도해 주세요.");
	        resp.sendRedirect(req.getContextPath() + "/member/join/join.jsp");
	    }
	}

}
