package com.ssafy.video.model.dto;

import java.util.List;

import com.ssafy.board.model.dto.Board;

public class Video {

	private int videoId;
	private String videoTitle;
	private String videoLink;
	private String videoPath;
	private String videoTarget;
	private String videoLevel;
	private String videoTargetPath;
	
	public Video() {
	}

	public Video(int videoId, String videoTitle, String videoLink, String videoPath, String videoTarget,
			String videoLevel, String videoTargetPath) {
		super();
		this.videoId = videoId;
		this.videoTitle = videoTitle;
		this.videoLink = videoLink;
		this.videoPath = videoPath;
		this.videoTarget = videoTarget;
		this.videoLevel = videoLevel;
		this.videoTargetPath=videoTargetPath;
	}

	public int getVideoId() {
		return videoId;
	}

	public void setVideoId(int videoId) {
		this.videoId = videoId;
	}

	public String getVideoTitle() {
		return videoTitle;
	}

	public void setVideoTitle(String videoTitle) {
		this.videoTitle = videoTitle;
	}

	public String getVideoLink() {
		return videoLink;
	}

	public void setVideoLink(String videoLink) {
		this.videoLink = videoLink;
	}

	public String getVideoPath() {
		return videoPath;
	}

	public void setVideoPath(String videoPath) {
		this.videoPath = videoPath;
	}

	public String getVideoTarget() {
		return videoTarget;
	}

	public void setVideoTarget(String videoTarget) {
		this.videoTarget = videoTarget;
	}

	public String getVideoLevel() {
		return videoLevel;
	}

	public void setVideoLevel(String videoLevel) {
		this.videoLevel = videoLevel;
	}

	public String getVideoTargetPath() {
		return videoTargetPath;
	}

	public void setVideoTargetPath(String videoTargetPath) {
		this.videoTargetPath = videoTargetPath;
	}

	@Override
	public String toString() {
		return "Video [videoId=" + videoId + ", videoTitle=" + videoTitle + ", videoLink=" + videoLink + ", videoPath="
				+ videoPath + ", videoTarget=" + videoTarget + ", videoLevel=" + videoLevel + ", videoTargetPath="
				+ videoTargetPath + "]";
	}
	
	

}
