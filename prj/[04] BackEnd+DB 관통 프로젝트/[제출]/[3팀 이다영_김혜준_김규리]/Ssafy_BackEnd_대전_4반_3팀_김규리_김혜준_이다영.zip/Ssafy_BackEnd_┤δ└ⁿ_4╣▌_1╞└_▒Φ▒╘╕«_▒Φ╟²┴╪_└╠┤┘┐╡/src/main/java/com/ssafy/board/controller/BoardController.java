package com.ssafy.board.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import com.ssafy.board.model.dto.Board;
import com.ssafy.board.model.service.BoardService;
import com.ssafy.board.model.service.BoardServiceImpl;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/*
 *  action 파리미터의 값으로 각각의 동작을 구분
 *  등록폼	: writeForm
 *  등록	: write
 *  목록	: list
 *  삭제 : delete
 *  수정폼 : updateForm
 *  수정 : update
 *  상세조회 : detail
 */
@WebServlet("/board")
public class BoardController extends HttpServlet {
	private BoardService boardService;

	public BoardController() {
		boardService = BoardServiceImpl.getInstance();

	}

//	private BoardDAO boardDao;

//	public BoardController() {
//		boardDao = BoardDAOImpl.getIntstance();
//	}

	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String action = req.getParameter("action");
		if ("list".equals(action)) {
			// 목록 페이지
			try {
				list(req, resp);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else if ("writeForm".equals(action)) {
			// 등록폼 페이지 이동하자...
			try {
				writeForm(req, resp);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else if ("write".equals(action)) {
			// 등록 처리하자...
			try {
				write(req, resp);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else if ("detail".equals(action)) {
			try {
				detail(req, resp);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else if ("delete".equals(action)) {
			try {
				delete(req, resp);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else if ("updateForm".equals(action)) {
			try {
				updateForm(req, resp);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else if ("update".equals(action)) {
			try {
				update(req, resp);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	private void list(HttpServletRequest req, HttpServletResponse resp) throws Exception {
		// 화면에 보여줄 데이터를 준비한다

//		// req 같이 볼 수 있는 영역에 올리자(공유영역)
		List<Board> list = boardService.listBoard();
		req.setAttribute("list", list);

		HttpSession session = req.getSession();
		session.setAttribute("list", list);
		// 화면 페이지로 이동한다.(list.jsp)
		RequestDispatcher rd = req.getRequestDispatcher("/board/list.jsp");
		rd.forward(req, resp);
	}

	private void write(HttpServletRequest req, HttpServletResponse resp) throws Exception {
		// 등록할 데이터를 파라미터에서 꺼낸다.
		String title = req.getParameter("title");
		String writer = req.getParameter("writer");
		String content = req.getParameter("content");
		int video = Integer.parseInt(req.getParameter("video"));

		Board board = new Board();
		board.setTitle(title);
		board.setWriter(writer);
		board.setContent(content);
		board.setVideo(video);

		boardService.insertBoard(board);
		resp.sendRedirect(req.getContextPath() + "/board?action=list");

		System.out.println("title : " + title);
		System.out.println("writer : " + writer);
		System.out.println("content : " + content);
		System.out.println("video : " + video);
		// 등록한다.
		// http://localhost/board-step01-mvc/board
		// 목록 페이지로 이동한다.(목록에 필요한 데이터를 준비하는 서블릿으로 이동)
//		RequestDispatcher rd = req.getRequestDispatcher("/board?action=list");
//		rd.forward(req, resp);

	}

	private void writeForm(HttpServletRequest req, HttpServletResponse resp) throws Exception {
		// 등록 페이지로 이동한다.
		RequestDispatcher rd = req.getRequestDispatcher("/board/write.jsp");
		rd.forward(req, resp);
	}

	private void detail(HttpServletRequest req, HttpServletResponse resp) throws Exception {
		// 조회할 게시글 번호 가져오기
		int no = Integer.parseInt(req.getParameter("no"));

		boardService.updateViewCount(no);

		Board board = boardService.selectBoardByNo(no);

		System.out.println(board);
		// 페이지에 넘길거임 -> (로그인 빼고는 거의 req에 담음)
		req.setAttribute("board", board);
		// 포워드 방식으로 가야함 ( 데이터 공유는 포워드만 가능함 )
		RequestDispatcher rd = req.getRequestDispatcher("/board/detail.jsp");
		rd.forward(req, resp);
	}

	private void delete(HttpServletRequest req, HttpServletResponse resp) throws Exception {
		int no = Integer.parseInt(req.getParameter("no"));
		boardService.deleteBoard(no);

		// 삭제했으니 목록으로 돌아가!
		// 삭제된 링크가 유지되면 안되므로 리다이렉트로 해야함!
		resp.sendRedirect(req.getContextPath() + "/board?action=list");
	}

	private void updateForm(HttpServletRequest req, HttpServletResponse resp) throws Exception {
		// 업데이트 페이지로 이동
		int no = Integer.parseInt(req.getParameter("no"));
		Board board = boardService.selectBoardByNo(no);

		req.setAttribute("board", board);
		RequestDispatcher rd = req.getRequestDispatcher("/board/update.jsp");
		rd.forward(req, resp);
	}

	private void update(HttpServletRequest req, HttpServletResponse resp) throws Exception {
		String title = "(수정)";
		title += req.getParameter("title");
		String content = req.getParameter("content");
		String regDate = req.getParameter("regDate");
		int no = Integer.parseInt(req.getParameter("no"));

		// 서비스 클래스를 통해 게시글을 조회하고 데이터를 수정한다.
		Board board = boardService.selectBoardByNo(no);
		if (board != null) {
			board.setTitle(title);
			board.setContent(content);
			board.setRegDate(regDate);
			boardService.updateBoard(board);
		}

//		board.setTitle(title);
//		board.setContent(content);
		resp.sendRedirect(req.getContextPath() + "/board?action=list");

	}
}
