package com.ssafy.member.model.service;

import java.sql.SQLException;

import com.ssafy.member.model.dto.Member;

public interface MemberService {
    boolean joinMember(Member member) throws SQLException;
    Member loginMember(Member member) throws SQLException;
}
