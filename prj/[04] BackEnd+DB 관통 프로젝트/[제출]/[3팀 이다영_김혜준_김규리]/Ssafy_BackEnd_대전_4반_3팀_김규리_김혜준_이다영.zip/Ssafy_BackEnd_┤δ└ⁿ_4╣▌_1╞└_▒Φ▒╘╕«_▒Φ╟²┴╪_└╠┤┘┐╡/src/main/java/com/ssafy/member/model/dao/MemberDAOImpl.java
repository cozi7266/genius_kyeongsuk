package com.ssafy.member.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.ssafy.member.model.dto.Member;
import com.ssafy.util.DBUtil;

public class MemberDAOImpl implements MemberDAO {

	public static void main(String[] args) throws SQLException {
		DBUtil dbUtil = DBUtil.getInstance();
		Connection con = dbUtil.getConnection();
		System.out.println(con);
	}

	// 싱글톤
	private MemberDAOImpl() {
	}

	private static MemberDAO instance = new MemberDAOImpl();

	public static MemberDAO getInstance() {
		return instance;
	}


	// 회원가입
	@Override
	public boolean joinMember(Member member) throws SQLException {
	    DBUtil dbUtil = DBUtil.getInstance();
	    Connection con = null;
	    PreparedStatement pstmt = null;
	    ResultSet rs = null;

	    try {
	        con = dbUtil.getConnection();
	        
	        String sql = "select * from member where member_id = ?";
	        
	        pstmt = con.prepareStatement(sql);
	        pstmt.setString(1, member.getId());
	        rs = pstmt.executeQuery();
	        
	        if (rs.next()) {
	        	return false;
	        }
	        
	        if (rs != null) try { rs.close(); } catch (SQLException e) { e.printStackTrace(); }
	        if (pstmt != null) try { pstmt.close(); } catch (SQLException e) { e.printStackTrace(); }

	        String sqlInsert = "insert into member(member_id, member_name, member_email, member_password) values(?, ?, ?, ?)";
	        pstmt = con.prepareStatement(sqlInsert);
	        pstmt.setString(1, member.getId());
	        pstmt.setString(2, member.getName());
	        pstmt.setString(3, member.getEmail());
	        pstmt.setString(4, member.getPassword());

	        pstmt.executeUpdate();
	        
	        // 자동 커밋이 비활성화된 경우 수동으로 커밋
//	        /con.commit();
	        return true;

	    } catch (SQLException e) {
	        e.printStackTrace(); // 예외 발생 시 로그 확인
	        return false;
	    } finally {
	        // 자원 해제
	    	if (rs != null) try { rs.close(); } catch (SQLException e) { e.printStackTrace(); }
	        if (pstmt != null) try { pstmt.close(); } catch (SQLException e) { e.printStackTrace(); }
	        if (con != null) try { con.close(); } catch (SQLException e) { e.printStackTrace(); }
	    }
	}

	// 로그인
	@Override
	public Member loginMember(Member member) throws SQLException {
		DBUtil dbUtil = DBUtil.getInstance();
		Connection con = dbUtil.getConnection();

		String sql = "select * from member where member_id = ?";

		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, member.getId());
		ResultSet rs = pstmt.executeQuery();

		if (rs.next()) {
			String id = rs.getString("member_id");
			String name = rs.getString("member_name");
			String email = rs.getString("member_email");
			String password = rs.getString("member_password");

			if (member.getPassword().equals(password)) {
				return new Member(id, name, email, password);
			} else {
				return null;
			}
		}
		return null;
	}

}
