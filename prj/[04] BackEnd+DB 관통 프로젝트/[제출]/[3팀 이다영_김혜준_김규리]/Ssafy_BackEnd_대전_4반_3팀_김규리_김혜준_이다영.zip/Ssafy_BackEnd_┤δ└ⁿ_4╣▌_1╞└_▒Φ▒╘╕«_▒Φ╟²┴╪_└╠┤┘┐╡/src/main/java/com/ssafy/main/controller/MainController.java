package com.ssafy.main.controller;

import java.io.IOException;
import java.util.List;

import com.ssafy.board.model.dao.BoardDAO;
import com.ssafy.board.model.dao.BoardDAOImpl;
import com.ssafy.board.model.dto.Board;
import com.ssafy.video.model.dao.VideoDAO;
import com.ssafy.video.model.dao.VideoDAOImpl;
import com.ssafy.video.model.dto.Video;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/main")
public class MainController extends HttpServlet {
	
//    private BoardDAO boardDao;  
//    private VideoDAO videoDao; 
//    
//    public MainController() {
//    	boardDao = BoardDAOImpl.getIntstance();
//    	videoDao = VideoDAOImpl.getIntstance();
//    }
//
//	
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

//		try {
//			// 1. board 리스트 가져오기
//			List<Board> boardList = boardDao.selectBoard();
//			req.setAttribute("boardList", boardList); // boardList를 공유영역에 저장
//
//			// 2. video 리스트 가져오기
//			List<Video> videoList = videoDao.selectVideoAll();
//			req.setAttribute("videoList", videoList); // videoList를 공유영역에 저장
//
//			// 3. main.jsp로 이동하여 boardList와 videoList 모두 넘기기
//			RequestDispatcher rd = req.getRequestDispatcher("/main.jsp");
//			rd.forward(req, resp);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
		RequestDispatcher rd = req.getRequestDispatcher("/video");
		rd.forward(req, resp);
		
//		rd = req.getRequestDispatcher("/board");
//		rd.forward(req, resp);

	}
}
