package com.ssafy.video.model.service;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.ssafy.board.model.dao.BoardDAO;
import com.ssafy.board.model.dao.BoardDAOImpl;
import com.ssafy.board.model.dto.Board;
import com.ssafy.video.model.dao.VideoDAO;
import com.ssafy.video.model.dao.VideoDAOImpl;
import com.ssafy.video.model.dto.Video;

public class VideoServiceImpl implements VideoService{
	   private VideoDAO videoDao;
	   private BoardDAO boardDao;
	    private static VideoService instance = new VideoServiceImpl();

	    private VideoServiceImpl() {
	        videoDao = VideoDAOImpl.getIntstance();
	        boardDao = BoardDAOImpl.getIntstance();
	    }

	    public static VideoService getInstance() {
	        return instance;
	    }
	
	
	
	
	
	@Override
	public List<Video> listVideoEasy() throws SQLException {
		 return videoDao.selectVideoEasy();
	}

	@Override
	public List<Video> listVideoHard() throws SQLException {
		return videoDao.selectVideoHard();
	}

	@Override
	public List<Video> listVideoAll() throws SQLException {
		return videoDao.selectVideoAll();
	}

	@Override
	public Map<String, Object> getVideoByNo(int videoId) throws SQLException {
		Video video = videoDao.selectVideoByNo(videoId);
		List<Board> boards = boardDao.selectBoardByVideoNo(videoId);
		Map<String, Object> result = new HashMap<>();
		result.put("video", video);
		result.put("boards", boards);
		return result;
	}

}
