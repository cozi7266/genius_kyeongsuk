package com.ssafy.member.model.service;

import java.sql.SQLException;

import com.ssafy.member.model.dao.MemberDAO;
import com.ssafy.member.model.dao.MemberDAOImpl;
import com.ssafy.member.model.dto.Member;

public class MemberServiceImpl implements MemberService{

    private MemberDAO memberDao;

    private static MemberService instance = new MemberServiceImpl();

    private MemberServiceImpl() {
        memberDao = MemberDAOImpl.getInstance();
    }

    public static MemberService getInstance() {
        return instance;
    }
	
	
	@Override
	public boolean joinMember(Member member) throws SQLException {
		boolean result = memberDao.joinMember(member);
		System.out.println(result);
		return result;
	}

	@Override
	public Member loginMember(Member member) throws SQLException {
		return memberDao.loginMember(member);
	}

}
