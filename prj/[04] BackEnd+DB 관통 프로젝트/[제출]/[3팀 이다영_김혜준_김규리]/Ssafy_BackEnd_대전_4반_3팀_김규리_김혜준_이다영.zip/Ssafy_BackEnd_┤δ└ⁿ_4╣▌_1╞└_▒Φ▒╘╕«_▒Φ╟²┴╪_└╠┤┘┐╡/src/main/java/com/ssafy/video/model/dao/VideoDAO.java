package com.ssafy.video.model.dao;

import java.sql.SQLException;
import java.util.List;

import com.ssafy.video.model.dto.Video;

public interface VideoDAO {

	Video selectVideoByNo(int videoId) throws SQLException;

	List<Video> selectVideoHard() throws SQLException;

	List<Video> selectVideoEasy() throws SQLException;

	List<Video> selectVideoAll() throws SQLException;

}
