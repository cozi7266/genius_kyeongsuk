package com.ssafy.board.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ssafy.board.model.dto.Board;
import com.ssafy.util.DBUtil;

// CRUD 기능 구축
/*
 * 데이터베이스 처리 기준(4반이 정하자!)
 * R : selectBoard(전체)
 *   : selectBoardByPK(하나만조회 primary key)
 * C : insertBoard
 * U : updateBoard
 * D : deleteBoard
 * 
 */
public class BoardDAOImpl implements BoardDAO {
	
	private DBUtil dbUtil;
	private static BoardDAO instance = new BoardDAOImpl();
	private BoardDAOImpl() {
		dbUtil = DBUtil.getInstance();
	};
	public static BoardDAO getIntstance() {
		return instance;
	}
	
	
	public static void main(String[] args) throws SQLException {
		DBUtil dbUtil =DBUtil.getInstance();
		Connection con = dbUtil.getConnection();
		System.out.println(con);
		
	}
	
	@Override
	public List<Board> selectBoard() throws SQLException{
		
		List<Board> list = new ArrayList<>();
		
		DBUtil dbUtil =DBUtil.getInstance();
		// 데이터베이스 연결하기
		Connection con = dbUtil.getConnection();
		// 실행할 SQL 문 작성
		String sql = "select REVIEW_NO, REVIEW_TITLE, MEMBER_ID, REVIEW_VIEW_CNT, REVIEW_REG_DATA, VIDEO_ID  from board order by REVIEW_NO desc";
		// SQL문을 실행할 객체를 얻어온다.
		PreparedStatement pstmt = con.prepareStatement(sql);
		// SQL문 실행하기 : select(executeQuery), select절 이외(executeUpdate) 
		ResultSet rs = pstmt.executeQuery();
		
		while(rs.next()) { //쿼리문 하나 내려가는 것...!
			int no = rs.getInt("REVIEW_NO");
			String title = rs.getString("REVIEW_TITLE");
			String writer = rs.getString("MEMBER_ID");
			int viewCnt = rs.getInt("REVIEW_VIEW_CNT");
			String regDate = rs.getString("REVIEW_REG_DATA"); 
			int video = rs.getInt("VIDEO_ID"); 
			
			Board board = new Board();
			board.setNo(no);
			board.setTitle(title);
			board.setWriter(writer);
			board.setViewCnt(viewCnt);
			board.setRegDate(regDate);
			board.setVideo(video);
			list.add(board);
		}
		return list;
	}


	// 게시글 번호
//	private static int boardNo = 1;

//	private List<Board> boardList = new ArrayList<>();

	@Override
	public void insertBoard(Board board) throws SQLException {
		
		DBUtil dbUtil =DBUtil.getInstance();
		// 데이터베이스 연결하기
		Connection con = dbUtil.getConnection();
		String sql = "insert board(REVIEW_TITLE,MEMBER_ID,REVIEW_CONTENT,VIDEO_ID) values(?,?,?,?)";
		PreparedStatement pstmt = con.prepareStatement(sql);
		
		String title = board.getTitle();
		String writer = board.getWriter();
		String content = board.getContent();
		int video = board.getVideo();
		
		pstmt.setString(1, title); // 첫번째 물음표에 no를 설정하겠다.
		pstmt.setString(2, writer); 
		pstmt.setString(3, content); 
		pstmt.setInt(4, video); 
		pstmt.executeUpdate();
		
//		board.setNo(boardNo++);
//		boardList.add(board);
	}
//
//	@Override
//	public List<Board> selectBoard() {
//		return boardList;
//	}

	@Override
	public Board selectBoardByNo(int no) throws SQLException {
		
		DBUtil dbUtil =DBUtil.getInstance();
		// 데이터베이스 연결하기
		Connection con = dbUtil.getConnection();
		// 실행할 SQL 문 작성
		String sql = "select REVIEW_NO, REVIEW_TITLE, MEMBER_ID, REVIEW_CONTENT, REVIEW_VIEW_CNT, REVIEW_REG_DATA, VIDEO_ID from board where REVIEW_NO = ?";
		// SQL문을 실행할 객체를 얻어온다.
		PreparedStatement pstmt = con.prepareStatement(sql);
		
		// 쿼리문 실행하기 전에 ?에 값을 설정
		pstmt.setInt(1,no); // 물음표의 위칫값, 값
		
		// SQL문 실행하기 : select(executeQuery), select절 이외(executeUpdate) 
		ResultSet rs = pstmt.executeQuery();
		
		if(rs.next()) {
			String title = rs.getString("REVIEW_TITLE");
			String writer = rs.getString("MEMBER_ID");
			String content = rs.getString("REVIEW_CONTENT");
			int viewCnt = rs.getInt("REVIEW_VIEW_CNT");
			String regDate = rs.getString("REVIEW_REG_DATA"); 
			int video = rs.getInt("VIDEO_ID"); 
			
			Board board = new Board();
			board.setNo(no);
			board.setTitle(title);
			board.setWriter(writer);
			board.setContent(content);
			board.setViewCnt(viewCnt);
			board.setRegDate(regDate);
			board.setVideo(video);
			return board;
		}
		return null;
//		for (int i = 0; i < boardList.size(); i++) {
//			if ((i + 1) == no) {
//				return boardList.get(i);
//			}
//		}
//		return null;

//		for(Board b: boardList) {
//			if(b.getNo()==no) {
//				return b;
//			}
//		}
//		return null;
	}

	@Override
	public void deleteByNo(int no) throws SQLException {
		
		DBUtil dbUtil =DBUtil.getInstance();
		// 데이터베이스 연결하기
		Connection con = dbUtil.getConnection();
		
		String sql = "delete from board where REVIEW_NO = ?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, no); // 첫번째 물음표에 no를 설정하겠다.
		pstmt.executeUpdate();
		
		
	}

	@Override
	public void updateViewCnt(int no) throws SQLException {
		
		DBUtil dbUtil =DBUtil.getInstance();
		// 데이터베이스 연결하기
		Connection con = dbUtil.getConnection();
		
		String sql = "update board set REVIEW_VIEW_CNT = REVIEW_VIEW_CNT+1 where REVIEW_NO = ?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, no); // 첫번째 물음표에 no를 설정하겠다.
		pstmt.executeUpdate();

	}
	
	@Override
	public void updateBoard(Board board) throws SQLException {
		
		DBUtil dbUtil =DBUtil.getInstance();
		// 데이터베이스 연결하기
		Connection con = dbUtil.getConnection();
		
		int no = board.getNo();
		String title = board.getTitle();
		String content = board.getContent();
		
		
		String sql = "update board set REVIEW_TITLE = ?, REVIEW_CONTENT = ? , REVIEW_REG_DATA = now() where REVIEW_NO = ?";

		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, title); 
		pstmt.setString(2, content);
		pstmt.setInt(3, no);
		pstmt.executeUpdate();

	}
	@Override
	public List<Board> selectBoardByVideoNo(int videoId) throws SQLException {
		
		List<Board> list = new ArrayList<>();
		
		DBUtil dbUtil =DBUtil.getInstance();
		// 데이터베이스 연결하기
		Connection con = dbUtil.getConnection();
		// 실행할 SQL 문 작성
		String sql = "select REVIEW_NO, REVIEW_TITLE, MEMBER_ID, REVIEW_VIEW_CNT, REVIEW_REG_DATA, VIDEO_ID  from board where video_id = ? order by REVIEW_NO desc";
		// SQL문을 실행할 객체를 얻어온다.
		PreparedStatement pstmt = con.prepareStatement(sql);
		// SQL문 실행하기 : select(executeQuery), select절 이외(executeUpdate)
		pstmt.setInt(1, videoId);
		ResultSet rs = pstmt.executeQuery();
		
		while(rs.next()) { //쿼리문 하나 내려가는 것...!
			int no = rs.getInt("REVIEW_NO");
			String title = rs.getString("REVIEW_TITLE");
			String writer = rs.getString("MEMBER_ID");
			int viewCnt = rs.getInt("REVIEW_VIEW_CNT");
			String regDate = rs.getString("REVIEW_REG_DATA"); 
			int video = rs.getInt("VIDEO_ID"); 
			
			Board board = new Board();
			board.setNo(no);
			board.setTitle(title);
			board.setWriter(writer);
			board.setViewCnt(viewCnt);
			board.setRegDate(regDate);
			board.setVideo(video);
			list.add(board);
		}
		return list;
	}	
}
