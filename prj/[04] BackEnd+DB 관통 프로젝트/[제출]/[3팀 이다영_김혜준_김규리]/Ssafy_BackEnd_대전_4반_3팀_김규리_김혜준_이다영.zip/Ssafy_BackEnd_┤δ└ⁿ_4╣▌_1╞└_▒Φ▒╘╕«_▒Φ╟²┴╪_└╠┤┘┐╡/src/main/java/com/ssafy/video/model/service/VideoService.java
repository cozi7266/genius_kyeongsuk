package com.ssafy.video.model.service;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import com.ssafy.video.model.dto.Video;

public interface VideoService {
	   List<Video> listVideoEasy() throws SQLException;
	    List<Video> listVideoHard() throws SQLException;
	    List<Video> listVideoAll() throws SQLException;
	    Map<String, Object> getVideoByNo(int videoId) throws SQLException;
}
